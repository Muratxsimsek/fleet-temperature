#!/bin/bash

# WAL Monitoring Script for Fleet Temperature Dashboard
# PostgreSQL WAL durumunu izler ve performans metriklerini gösterir

echo "🔍 WAL Monitoring - Fleet Temperature Dashboard"
echo "================================================"

# PostgreSQL container'ına bağlan
CONTAINER="fleet-temperature-dashboard-db"

echo ""
echo "📊 WAL Statistics:"
docker exec $CONTAINER psql -U postgres -d fleet_temperature -c "
SELECT 
    name,
    setting,
    unit,
    context
FROM pg_settings 
WHERE name LIKE '%wal%' OR name LIKE '%checkpoint%'
ORDER BY name;
"

echo ""
echo "📈 WAL Activity:"
docker exec $CONTAINER psql -U postgres -d fleet_temperature -c "
SELECT 
    pg_current_wal_lsn() as current_wal_lsn,
    pg_walfile_name(pg_current_wal_lsn()) as current_wal_file,
    pg_size_pretty(pg_wal_lsn_diff(pg_current_wal_lsn(), '0/0')) as total_wal_size,
    pg_size_pretty(pg_wal_lsn_diff(pg_current_wal_lsn(), pg_last_wal_receive_lsn())) as replication_lag;
"

echo ""
echo "🔄 Checkpoint Status:"
docker exec $CONTAINER psql -U postgres -d fleet_temperature -c "
SELECT 
    checkpoints_timed,
    checkpoints_req,
    checkpoint_write_time,
    checkpoint_sync_time,
    buffers_checkpoint,
    buffers_clean,
    maxwritten_clean,
    buffers_backend,
    buffers_backend_fsync,
    buffers_alloc
FROM pg_stat_bgwriter;
"

echo ""
echo "💾 Database Size:"
docker exec $CONTAINER psql -U postgres -d fleet_temperature -c "
SELECT 
    schemaname,
    tablename,
    pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)) as size
FROM pg_tables 
WHERE schemaname NOT IN ('information_schema', 'pg_catalog')
ORDER BY pg_total_relation_size(schemaname||'.'||tablename) DESC
LIMIT 10;
"

echo ""
echo "⚡ TimescaleDB Status:"
docker exec $CONTAINER psql -U postgres -d fleet_temperature -c "
SELECT 
    hypertable_name,
    num_chunks,
    compression_enabled,
    compression_status
FROM timescaledb_information.hypertables;
"

echo ""
echo "📝 Active Connections:"
docker exec $CONTAINER psql -U postgres -d fleet_temperature -c "
SELECT 
    count(*) as active_connections,
    max_conn as max_connections
FROM pg_stat_activity, 
     (SELECT setting::int as max_conn FROM pg_settings WHERE name='max_connections') as max_conn;
"
