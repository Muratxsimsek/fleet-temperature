# 🚀 Fleet Temperature Frontend - API Update & Compatibility

## 📋 **Overview**
Bu dokümantasyon, `fleet-temperature-1` backend projesindeki response yapısı değişikliklerine göre yapılan FE güncellemelerini açıklar.

## 🔄 **Yapılan Güncellemeler**

### **1. 🏗️ API Configuration System**
- **Yeni Dosya**: `src/config/api.ts`
- **Merkezi Konfigürasyon**: Tüm API endpoint'leri ve field mapping'ler tek yerde
- **Esnek Yapı**: Farklı backend format'ları için uyumluluk

### **2. 🔌 Multi-Endpoint Support**
- **Fallback Sistemi**: Bir endpoint başarısız olursa diğerini dene
- **Endpoint'ler**:
  - `/api/aircraft-temperatures` (Primary)
  - `/api/aircrafts` (Alternative)
  - `/api/temperature-alarms` (Primary)
  - `/api/active-alarms` (Alternative)

### **3. 🎯 Field Mapping System**
- **Esnek Field Mapping**: Farklı backend response format'ları için
- **Fallback Values**: Field bulunamazsa default değerler
- **Type Safety**: TypeScript ile güvenli field access

### **4. 🎁 Wrapper Response Format Support**
- **Success/Error Wrapper**: `{ success, message, data, errorCode, timestamp }`
- **Backward Compatibility**: Eski direct response format'ı da desteklenir
- **Error Handling**: API error'ları için structured error handling

## 📊 **Field Mapping Detayları**

### **Aircraft Fields**
```typescript
ID: ['id', 'aircraftId', 'aircraft_id', 'registration']
REGISTRATION: ['registration', 'aircraftId', 'id', 'tailNumber']
MODEL: ['model', 'aircraftModel', 'type', 'aircraftType']
STATUS: ['status', 'aircraftStatus', 'state', 'condition']
TEMPERATURE: ['currentTemperature', 'temperature', 'temp', 'cabinTemp']
ZONE: ['cabinZone', 'zone', 'section', 'cabinSection']
ROUTE: ['route', 'flightRoute', 'destination', 'flightPath']
```

### **Alarm Fields**
```typescript
ID: ['id', 'alarmId', 'alarm_id']
AIRCRAFT_ID: ['aircraftId', 'aircraft_id', 'aircraft']
ZONE: ['cabinZone', 'cabin_zone', 'zone', 'section']
SEVERITY: ['status', 'severity', 'level', 'priority']
TEMPERATURE: ['temperatureCelsius', 'temperature_celsius', 'temp']
```

### **Temperature Fields**
```typescript
ID: ['id', 'readingId', 'reading_id']
AIRCRAFT_ID: ['aircraftId', 'aircraft_id', 'aircraft']
ZONE: ['cabinZone', 'cabin_zone', 'zone', 'section']
CELSIUS: ['temperatureCelsius', 'temperature_celsius', 'temp', 'celsius']
FAHRENHEIT: ['temperatureFahrenheit', 'temperature_fahrenheit', 'fahrenheit']
```

## 🛠️ **Kullanım Örnekleri**

### **Field Value Extraction**
```typescript
import { getFieldValue, API_CONFIG } from '../config/api';

// Flexible field access
const aircraftId = getFieldValue(
  aircraft, 
  API_CONFIG.FIELD_MAPPINGS.AIRCRAFT.ID, 
  'UNKNOWN'
);
```

### **API URL Building**
```typescript
import { buildApiUrl, API_CONFIG } from '../config/api';

// Dynamic URL building
const url = buildApiUrl(API_CONFIG.ENDPOINTS.AIRCRAFT_TEMPERATURES);
const historyUrl = buildApiUrl(API_CONFIG.ENDPOINTS.AIRCRAFT_HISTORY, { id: 'TC-JJ0' });
```

### **Wrapper Response Handling**
```typescript
import { handleApiResponse, parseWrapperResponse } from '../config/api';

// Automatic wrapper response parsing
const aircraftData = await handleApiResponse(response);

// Manual wrapper response parsing
const parsedResponse = parseWrapperResponse(responseData);
if (parsedResponse.success) {
  setAircrafts(parsedResponse.data);
} else {
  console.error('API Error:', parsedResponse.message, parsedResponse.errorCode);
}
```

## 🔧 **Backend Uyumluluğu**

### **Desteklenen Response Format'ları**

#### **1. 🆕 Wrapper Response Format (Yeni)**
```json
{
  "success": true,
  "message": "Aircraft temperatures retrieved successfully",
  "data": [
    {
      "id": "TC-JJ0",
      "registration": "TC-JJ0",
      "model": "Boeing 737-800",
      "currentTemperature": 25.0,
      "cabinZone": "MID"
    }
  ],
  "errorCode": null,
  "timestamp": "2025-08-24T05:30:00"
}
```

#### **2. ❌ Error Response Format**
```json
{
  "success": false,
  "message": "Failed to retrieve temperature history",
  "data": [],
  "errorCode": "TEMPERATURE_HISTORY_ERROR",
  "timestamp": "2025-08-24T05:30:00"
}
```

#### **3. 🔄 Direct Response Format (Backward Compatibility)**
```json
[
  {
    "id": "TC-JJ0",
    "registration": "TC-JJ0",
    "model": "Boeing 737-800",
    "currentTemperature": 25.0,
    "cabinZone": "MID"
  }
]
```

#### **4. 🎯 Alternative Field Names (Flexible Mapping)**
```json
{
  "aircraftId": "TC-JJ0",
  "tailNumber": "TC-JJ0",
  "aircraftModel": "Boeing 737-800",
  "temperature": 25.0,
  "zone": "MID"
}
```

## 🚀 **Avantajlar**

### **1. 🔄 Backward Compatibility**
- Eski API format'ları desteklenir
- Mevcut sistemler etkilenmez

### **2. 🎯 Forward Compatibility**
- Yeni backend format'ları otomatik desteklenir
- Field mapping'ler kolayca güncellenebilir

### **3. 🛡️ Error Handling**
- Fallback sistem ile güvenilirlik
- Graceful degradation

### **4. 📝 Maintainability**
- Merkezi konfigürasyon
- Kolay güncelleme ve bakım

## 🔍 **Test Senaryoları**

### **1. 🆕 Wrapper Response Test**
```bash
# Test new wrapper response format
curl http://localhost:8080/api/aircraft-temperatures

# Expected response:
{
  "success": true,
  "message": "Aircraft temperatures retrieved successfully",
  "data": [...],
  "errorCode": null,
  "timestamp": "2025-08-24T05:30:00"
}
```

### **2. 🔄 Backward Compatibility Test**
```bash
# Test old direct response format (if still supported)
curl http://localhost:8080/api/aircrafts

# Expected response: [...]
```

### **3. 🧪 Frontend Test Utilities**
```typescript
// Import test utilities
import { testWrapperResponse, testApiEndpoints, testFieldMapping } from '../utils/apiTest';

// Test wrapper response parsing
testWrapperResponse();

// Test API endpoints
testApiEndpoints();

// Test field mapping
testFieldMapping();
```

## 📝 **Notlar**

- **Environment Variables**: `REACT_APP_API_BASE_URL` ile base URL değiştirilebilir
- **WebSocket**: Port 8082'de çalışır (configurable)
- **Fallback**: Tüm endpoint'ler başarısız olursa mock data kullanılır
- **Performance**: Field mapping'ler optimize edilmiştir

## 🔮 **Gelecek Geliştirmeler**

1. **API Versioning**: `/api/v1/`, `/api/v2/` desteği
2. **Rate Limiting**: API call limit'leri
3. **Caching**: Response caching sistemi
4. **Retry Logic**: Otomatik retry mekanizması
5. **Health Checks**: Endpoint health monitoring

---

**Son Güncelleme**: $(date)
**Versiyon**: 1.0.0
**Backend Uyumluluğu**: fleet-temperature-1 ✅
