// API Configuration for Fleet Temperature System
export const API_CONFIG = {
  // Base URLs
  BASE_URL: process.env.REACT_APP_API_BASE_URL || 'http://localhost:8080',
  API_VERSION: 'v1',
  
  // Endpoints
  ENDPOINTS: {
    // Aircraft endpoints
    AIRCRAFT_TEMPERATURES: '/api/aircraft-temperatures',
    AIRCRAFTS: '/api/aircrafts',
    AIRCRAFT_HISTORY: '/api/aircraft/:id/temperatures',
    
    // Alarm endpoints
    TEMPERATURE_ALARMS: '/api/temperature-alarms',
    ACTIVE_ALARMS: '/api/active-alarms',
    ALARMS: '/api/alarms',
    
    // Temperature endpoints
    TEMPERATURES: '/api/temperatures',
    TEMPERATURE_READINGS: '/api/temperature-readings',
    
    // Route endpoints
    ROUTES: '/api/routes',
    ROUTE_ANALYSIS: '/api/route-analysis',
    
    // Zone endpoints
    ZONE_ANALYSIS: '/api/zone-analysis',
    ZONE_TEMPERATURES: '/api/zone-temperatures',
  },
  
  // WebSocket configuration
  WEBSOCKET: {
    BASE_URL: process.env.REACT_APP_WEBSOCKET_URL || 'http://localhost:8082',
    ENDPOINTS: {
      TEMPERATURE_UPDATES: '/topic/temperature-updates',
      AIRCRAFT_TEMPERATURE: '/topic/aircraft/:id/temperature',
      ALARM_UPDATES: '/topic/alarm-updates',
      STATUS_UPDATES: '/topic/status-updates',
    }
  },
  
  // Response field mappings for different backend formats
  FIELD_MAPPINGS: {
    AIRCRAFT: {
      ID: ['id', 'aircraftId', 'aircraft_id', 'registration'],
      REGISTRATION: ['registration', 'aircraftId', 'id', 'tailNumber'],
      MODEL: ['model', 'aircraftModel', 'type', 'aircraftType'],
      STATUS: ['status', 'aircraftStatus', 'state', 'condition'],
      TEMPERATURE: ['currentTemperature', 'temperature', 'temp', 'cabinTemp'],
      ZONE: ['cabinZone', 'zone', 'section', 'cabinSection'],
      ROUTE: ['route', 'flightRoute', 'flightPath', 'flightNumber', 'routeName', 'flightRouteName', 'flightPathName', 'flightRoute', 'routeName', 'flightRoute', 'routeName', 'flightRoute', 'routeName', 'flightRoute', 'routeName', 'flightRoute', 'routeName', 'flightRoute', 'routeName', 'flightRoute', 'routeName', 'flightRoute', 'routeName', 'flightRoute', 'routeName', 'flightRoute', 'routeName', 'flightRoute', 'routeName', 'flightRoute', 'routeName', 'flightRoute', 'routeName', 'flightRoute', 'routeName', 'flightRoute', 'routeName', 'flightRoute', 'routeName', 'flightRoute', 'routeName', 'flightRoute', 'routeName', 'flightRoute', 'routeName', 'flightRoute', 'routeName', 'flightRoute', 'routeName', 'flightRoute', 'routeName', 'flightRoute', 'routeName', 'flightRoute', 'routeName', 'flightRoute', 'routeName', 'flightRoute', 'routeName', 'flightRoute', 'routeName', 'flightRoute', 'routeName'],
      DEPARTURE: ['departure', 'origin', 'from', 'departureAirport', 'departureCity', 'departureLocation'],
      DESTINATION: ['destination', 'arrival', 'to', 'arrivalAirport', 'arrivalCity', 'arrivalLocation'],
      LAST_UPDATE: ['lastUpdate', 'updatedAt', 'timestamp', 'lastModified']
    },
    ALARM: {
      ID: ['id', 'alarmId', 'alarm_id'],
      AIRCRAFT_ID: ['aircraftId', 'aircraft_id', 'aircraft'],
      ZONE: ['cabinZone', 'cabin_zone', 'zone', 'section'],
      SEVERITY: ['status', 'severity', 'level', 'priority'],
      TEMPERATURE: ['temperatureCelsius', 'temperature_celsius', 'temp'],
      NOTES: ['notes', 'description', 'message', 'alert'],
      TIMESTAMP: ['timestamp', 'triggeredAt', 'created_at', 'createdAt']
    },
    TEMPERATURE: {
      ID: ['id', 'readingId', 'reading_id'],
      AIRCRAFT_ID: ['aircraftId', 'aircraft_id', 'aircraft'],
      ZONE: ['cabinZone', 'cabin_zone', 'zone', 'section'],
      CELSIUS: ['temperatureCelsius', 'temperature_celsius', 'temp', 'celsius'],
      FAHRENHEIT: ['temperatureFahrenheit', 'temperature_fahrenheit', 'fahrenheit'],
      STATUS: ['status', 'condition', 'state'],
      TIMESTAMP: ['timestamp', 'createdAt', 'created_at', 'readingTime'],
      NOTES: ['notes', 'description', 'message']
    }
  },

  // New wrapper response format support
  WRAPPER_RESPONSE: {
    SUCCESS: 'success',
    MESSAGE: 'message',
    DATA: 'data',
    ERROR_CODE: 'errorCode',
    TIMESTAMP: 'timestamp'
  },
  
  // Default values
  DEFAULTS: {
    AIRCRAFT: {
      STATUS: 'ACTIVE',
      TEMPERATURE: 22.0,
      ZONE: 'MID',
      MODEL: 'Unknown Model',
      ROUTE: 'Unknown Route'
    },
    ALARM: {
      SEVERITY: 'WARNING',
      NOTES: 'Temperature alert'
    }
  }
};

// Helper function to get field value with fallbacks
export const getFieldValue = (obj: any, fieldMappings: string[], defaultValue?: any): any => {
  for (const field of fieldMappings) {
    if (obj[field] !== undefined && obj[field] !== null) {
      return obj[field];
    }
  }
  return defaultValue;
};

// Helper function to build API URL
export const buildApiUrl = (endpoint: string, params?: Record<string, string>): string => {
  let url = `${API_CONFIG.BASE_URL}${endpoint}`;
  
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      url = url.replace(`:${key}`, value);
    });
  }
  
  return url;
};

// Helper function to parse wrapper response format
export const parseWrapperResponse = (response: any): { success: boolean; data: any; message?: string; errorCode?: string; timestamp?: string } => {
  // Check if response has wrapper format
  if (response && typeof response === 'object' && 'success' in response) {
    return {
      success: response.success,
      data: response.data || [],
      message: response.message,
      errorCode: response.errorCode,
      timestamp: response.timestamp
    };
  }
  
  // Fallback to direct response (backward compatibility)
  return {
    success: true,
    data: response || [],
    message: 'Direct response format',
    timestamp: new Date().toISOString()
  };
};

// Helper function to handle API responses with error handling
export const handleApiResponse = async (response: Response): Promise<any> => {
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`);
  }
  
  const responseData = await response.json();
  const parsedResponse = parseWrapperResponse(responseData);
  
  if (!parsedResponse.success) {
    throw new Error(`API Error: ${parsedResponse.message} (Code: ${parsedResponse.errorCode})`);
  }
  
  return parsedResponse.data;
};
