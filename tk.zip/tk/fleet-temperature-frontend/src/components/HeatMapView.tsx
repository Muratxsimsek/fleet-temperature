import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import './HeatMapView.css';
import { API_CONFIG, getFieldValue, buildApiUrl, handleApiResponse } from '../config/api';

interface Aircraft {
  id: string;
  registration: string;
  model: string;
  status: 'ACTIVE' | 'MAINTENANCE' | 'GROUNDED';
  currentTemperature: number;
  cabinZone: string;
  lastUpdate: string;
  route?: string;
  destination?: string;
  departure?: string;
}

interface RouteAnalysis {
  routeId: string;
  routeName: string;
  aircraftCount: number;
  avgTemperature: number;
  temperatureTrend: 'INCREASING' | 'DECREASING' | 'STABLE';
  criticalZones: string[];
  lastUpdate: string;
}

interface TemperatureReading {
  id: number;
  aircraftId: string;
  messageId: string | null;
  cabinZone: string;
  temperatureCelsius: number;
  temperatureFahrenheit: number;
  status: 'NORMAL' | 'WARNING' | 'CRITICAL';
  timestamp: string;
  notes: string | null;
  createdAt: string | null;
}

interface HeatMapViewProps {
  stompClient: any;
  isConnected: boolean;
  selectedAircraft: any;
  setSelectedAircraft: (aircraft: any) => void;
  aircrafts: any[];
  setAircrafts: (aircrafts: any[]) => void;
  websocketAircraftIds: Set<string>;
  setWebsocketAircraftIds: (ids: Set<string> | ((prev: Set<string>) => Set<string>)) => void;
}

  const HeatMapView: React.FC<HeatMapViewProps> = React.memo(({ 
    stompClient, 
    isConnected, 
    selectedAircraft, 
    setSelectedAircraft, 
    aircrafts, 
    setAircrafts, 
    websocketAircraftIds, 
    setWebsocketAircraftIds 
  }) => {

  const [temperatureHistory, setTemperatureHistory] = useState<TemperatureReading[]>([]);
  const [loading, setLoading] = useState(true);
  const [zoneTemperatures, setZoneTemperatures] = useState<{ [key: string]: number }>({});
  const [alarms, setAlarms] = useState<{ [key: string]: { severity: string; message: string; timestamp: string } }>({});
  const [lastUpdate, setLastUpdate] = useState(new Date());
  const [error, setError] = useState<string>('');
  const [startDate, setStartDate] = useState<string>('');
  const [endDate, setEndDate] = useState<string>('');
  const [realTimeData, setRealTimeData] = useState<{
    FWD: { temp: number; timestamp: Date }[];
    MID: { temp: number; timestamp: Date }[];
    AFT: { temp: number; timestamp: Date }[];
  }>({
    FWD: [],
    MID: [],
    AFT: []
  });

  const [showRulesModal, setShowRulesModal] = useState(false);
  const [routeAnalysis, setRouteAnalysis] = useState<RouteAnalysis[]>([]);
  const [selectedRoute, setSelectedRoute] = useState<string>('');
  const [selectedAircraftRoute, setSelectedAircraftRoute] = useState<string>('');
  const [routeChangeHistory, setRouteChangeHistory] = useState<{ [aircraftId: string]: string[] }>({});
  const [zoneAnalysis, setZoneAnalysis] = useState<{
    FWD: { avgTemp: number; trend: string; criticalCount: number };
    MID: { avgTemp: number; trend: string; criticalCount: number };
    AFT: { avgTemp: number; trend: string; criticalCount: number };
  }>({
    FWD: { avgTemp: 0, trend: 'STABLE', criticalCount: 0 },
    MID: { avgTemp: 0, trend: 'STABLE', criticalCount: 0 },
    AFT: { avgTemp: 0, trend: 'STABLE', criticalCount: 0 }
  });
  const heatmapChartRef = useRef<HTMLCanvasElement>(null);

  // Aircraft zones configuration - FWD/MID/AFT (All same size)
  const aircraftZones = useMemo(() => [
    { name: 'FWD', color: '#FF6B6B', x: 20, y: 30, width: 16, height: 30, description: 'Forward Section' },
    { name: 'MID', color: '#4ECDC4', x: 42, y: 30, width: 16, height: 30, description: 'Middle Section' },
    { name: 'AFT', color: '#45B7D1', x: 64, y: 30, width: 16, height: 30, description: 'Aft Section' },
  ], []);

  // Initialize date range
  useEffect(() => {
    const now = new Date();
    const oneDayAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);
    
    setStartDate(oneDayAgo.toISOString().slice(0, 16));
    setEndDate(now.toISOString().slice(0, 16));
  }, []);

  // WebSocket real-time update system
  useEffect(() => {
    if (!stompClient || !isConnected) return;

    console.log('🔥 Setting up HeatMap WebSocket subscriptions...');

    // Temperature updates subscription
    const tempSubscription = stompClient.subscribe('/topic/temperature-updates', (message: any) => {
      try {
        const tempReading: TemperatureReading = JSON.parse(message.body);
        console.log('🌡️ HeatMap Temperature Update:', tempReading);
        
        // Collect aircraft ID from WebSocket using API config
        const aircraftId = getFieldValue(tempReading, API_CONFIG.FIELD_MAPPINGS.TEMPERATURE.AIRCRAFT_ID, tempReading.aircraftId);
        if (aircraftId) {
          setWebsocketAircraftIds(prev => {
            const newSet = new Set(prev);
            newSet.add(aircraftId);
            console.log(`🆕 Added aircraft ${aircraftId} to WebSocket set. Current set:`, Array.from(newSet));
            return newSet;
          });
          
          // Check if temperature update contains route information - ONLY update if aircraft doesn't have route yet
          const routeFromWebSocket = getFieldValue(tempReading, API_CONFIG.FIELD_MAPPINGS.AIRCRAFT.ROUTE, undefined);
          const departureFromWebSocket = getFieldValue(tempReading, API_CONFIG.FIELD_MAPPINGS.AIRCRAFT.DEPARTURE, undefined);
          const destinationFromWebSocket = getFieldValue(tempReading, API_CONFIG.FIELD_MAPPINGS.AIRCRAFT.DESTINATION, undefined);
          
          if (routeFromWebSocket || departureFromWebSocket || destinationFromWebSocket) {
            console.log('🛫 Route info from WebSocket:', { 
              aircraftId, 
              route: routeFromWebSocket, 
              departure: departureFromWebSocket, 
              destination: destinationFromWebSocket,
              timestamp: new Date().toISOString()
            });
            
            // Log all WebSocket route messages for this aircraft
            console.log(`📡 WebSocket route message for ${aircraftId}:`, {
              fullMessage: tempReading,
              extractedRoute: routeFromWebSocket,
              currentAircraftRoute: 'Checking...'
            });
            
            // Track route changes in history - only when route actually changes
            (setAircrafts as any)((prev: any) => {
              if (Array.isArray(prev)) {
                const currentAircraft = prev.find(a => a.id === aircraftId);
                if (currentAircraft && currentAircraft.route !== routeFromWebSocket) {
                  // Route changed, update history
                  setRouteChangeHistory(prevHistory => {
                    const currentHistory = prevHistory[aircraftId] || [];
                    const newHistory = [...currentHistory, routeFromWebSocket || 'No Route'];
                    return {
                      ...prevHistory,
                      [aircraftId]: newHistory.slice(-10) // Keep last 10 route changes
                    };
                  });
                  console.log(`📊 Route changed for ${aircraftId}: "${currentAircraft.route}" -> "${routeFromWebSocket}"`);
                }
              }
              return prev;
            });
            
            // Only update route if aircraft doesn't have route information yet OR if this is the first time we see this route
            (setAircrafts as any)((prev: any) => {
              if (!Array.isArray(prev)) {
                console.warn('⚠️ prev is not an array:', prev);
                return prev;
              }
              return prev.map((aircraft: any) => {
                if (aircraft.id === aircraftId) {
                  // Check if we should update the route
                  const shouldUpdateRoute = !aircraft.route || 
                    aircraft.route === 'Unknown Route' || 
                    aircraft.route === 'WebSocket Route' ||
                    !routeChangeHistory[aircraftId] || // First time seeing this aircraft
                    routeChangeHistory[aircraftId].length === 0; // No route history yet
                  
                  if (shouldUpdateRoute && routeFromWebSocket) {
                    console.log(`🔄 Setting initial route for aircraft ${aircraftId}: "${routeFromWebSocket}"`);
                    return {
                      ...aircraft,
                      route: routeFromWebSocket,
                      departure: departureFromWebSocket || aircraft.departure,
                      destination: destinationFromWebSocket || aircraft.destination
                    };
                  } else if (aircraft.route && aircraft.route !== 'Unknown Route' && aircraft.route !== 'WebSocket Route') {
                    console.log(`✅ Keeping existing route for aircraft ${aircraftId}: "${aircraft.route}" (ignoring new route: "${routeFromWebSocket}")`);
                  }
                }
                return aircraft;
              });
            });
          }
        }
        
        // Update zone temperatures for selected aircraft
        if (selectedAircraft && aircraftId === selectedAircraft.id) {
          updateZoneTemperatures(tempReading);
          setLastUpdate(new Date());
          
          // Fetch latest alarms from backend
          fetchAlarms(aircraftId);
        }
      } catch (error) {
        console.error('❌ Error parsing temperature update in HeatMap:', error);
      }
    });

    // Aircraft-specific temperature subscription
    if (selectedAircraft) {
      const aircraftSubscription = stompClient.subscribe(`/topic/aircraft/${selectedAircraft.id}/temperature`, (message: any) => {
        try {
          const tempReading: TemperatureReading = JSON.parse(message.body);
          console.log('✈️ Aircraft-specific temperature update:', tempReading);
          updateZoneTemperatures(tempReading);
          checkAlarms(tempReading);
          setLastUpdate(new Date());
        } catch (error) {
          console.error('❌ Error parsing aircraft temperature update:', error);
        }
      });

      return () => {
        tempSubscription.unsubscribe();
        aircraftSubscription.unsubscribe();
      };
    }

    return () => {
      tempSubscription.unsubscribe();
    };
  }, [stompClient, isConnected, selectedAircraft]);

  // Update zone temperatures based on WebSocket data
  const updateZoneTemperatures = (tempReading: TemperatureReading) => {
    // Handle different temperature field names using API config
    const baseTemp = getFieldValue(tempReading, API_CONFIG.FIELD_MAPPINGS.TEMPERATURE.CELSIUS, 22.0);
    const now = new Date();
    
    // Calculate zone temperatures with realistic variations
    const newZoneTemps = {
      'FWD': baseTemp + (Math.random() - 0.5) * 3, // ±1.5°C variation
      'MID': baseTemp + (Math.random() - 0.5) * 2, // ±1°C variation
      'AFT': baseTemp + (Math.random() - 0.5) * 3, // ±1.5°C variation
    };
    
    setZoneTemperatures(newZoneTemps);
    
    // Store real-time data for chart
    setRealTimeData(prev => ({
      FWD: [...prev.FWD, { temp: newZoneTemps.FWD, timestamp: now }].slice(-50), // Keep last 50 readings
      MID: [...prev.MID, { temp: newZoneTemps.MID, timestamp: now }].slice(-50),
      AFT: [...prev.AFT, { temp: newZoneTemps.AFT, timestamp: now }].slice(-50)
    }));
    
    console.log('🔥 Zone temperatures updated:', newZoneTemps);
  };

  // Fetch alarms from backend
  const fetchAlarms = async (aircraftId?: string) => {
    try {
      console.log('🚨 Fetching alarms from backend...');
      
      // Try multiple endpoints for better compatibility
      let alarmData: any[] = [];
      
      // First try temperature-alarms endpoint
      try {
        let url = buildApiUrl(API_CONFIG.ENDPOINTS.TEMPERATURE_ALARMS);
        if (aircraftId) {
          url += `?aircraftId=${aircraftId}`;
        }
        
        const response = await fetch(url);
        if (response.ok) {
          alarmData = await handleApiResponse(response);
          console.log('✅ Alarms fetched from temperature-alarms endpoint:', alarmData);
        }
      } catch (error) {
        console.log('🔄 temperature-alarms endpoint failed, trying active-alarms...');
        console.error('Error details:', error);
      }
      
      // If no data, try active-alarms endpoint
      if (alarmData.length === 0) {
        try {
          const response = await fetch(buildApiUrl(API_CONFIG.ENDPOINTS.ACTIVE_ALARMS));
          if (response.ok) {
            alarmData = await handleApiResponse(response);
            console.log('✅ Alarms fetched from active-alarms endpoint:', alarmData);
          }
        } catch (error) {
          console.log('🔄 active-alarms endpoint also failed...');
          console.error('Error details:', error);
        }
      }
      
      if (alarmData.length === 0) {
        throw new Error('No alarm data available from any endpoint');
      }
      
      // Convert backend alarm format to our format
      const formattedAlarms: { [key: string]: { severity: string; message: string; timestamp: string } } = {};
      
      alarmData.forEach((alarm: any) => {
        // Handle different response formats using API config
        const alarmId = getFieldValue(alarm, API_CONFIG.FIELD_MAPPINGS.ALARM.ID, `ALM_${Date.now()}`);
        const aircraftId = getFieldValue(alarm, API_CONFIG.FIELD_MAPPINGS.ALARM.AIRCRAFT_ID, 'UNKNOWN');
        const cabinZone = getFieldValue(alarm, API_CONFIG.FIELD_MAPPINGS.ALARM.ZONE, 'UNKNOWN');
        const severity = getFieldValue(alarm, API_CONFIG.FIELD_MAPPINGS.ALARM.SEVERITY, API_CONFIG.DEFAULTS.ALARM.SEVERITY);
        const temp = getFieldValue(alarm, API_CONFIG.FIELD_MAPPINGS.ALARM.TEMPERATURE, 0);
        const notes = getFieldValue(alarm, API_CONFIG.FIELD_MAPPINGS.ALARM.NOTES, API_CONFIG.DEFAULTS.ALARM.NOTES);
        const timestamp = getFieldValue(alarm, API_CONFIG.FIELD_MAPPINGS.ALARM.TIMESTAMP, new Date().toISOString());
        
        const alarmKey = `${aircraftId}_${cabinZone}_${alarmId}`;
        formattedAlarms[alarmKey] = {
          severity: severity === 'CRITICAL' || severity === 'HIGH' ? 'CRITICAL' : 'WARNING',
          message: `${cabinZone} Zone: ${temp.toFixed(1)}°C - ${notes}`,
          timestamp: timestamp
        };
      });
      
      setAlarms(formattedAlarms);
      return formattedAlarms;
    } catch (error) {
      console.error('❌ Error fetching alarms from backend:', error);
      console.log('🔄 Falling back to local alarm detection...');
      
      // Fallback to local alarm detection
      return null;
    }
  };

  // Check for temperature alarms (fallback when backend fails)
  const checkAlarms = (tempReading: TemperatureReading) => {
    // Handle different temperature field names using API config
    const temp = getFieldValue(tempReading, API_CONFIG.FIELD_MAPPINGS.TEMPERATURE.CELSIUS, 22.0);
    const newAlarms: { [key: string]: { severity: string; message: string; timestamp: string } } = {};
    
    // CRITICAL Alarms (Kritik)
    if (temp > 35) {
      newAlarms['EXTREME_HIGH_TEMP'] = {
        severity: 'CRITICAL',
        message: `🚨 EXTREME: Temperature ${temp.toFixed(1)}°C - Immediate action required!`,
        timestamp: new Date().toISOString()
      };
    } else if (temp > 30) {
      newAlarms['HIGH_TEMP'] = {
        severity: 'CRITICAL',
        message: `🚨 CRITICAL: Temperature ${temp.toFixed(1)}°C exceeds critical limit!`,
        timestamp: new Date().toISOString()
      };
    }
    
    // WARNING Alarms (Uyarı)
    else if (temp > 28) {
      newAlarms['HIGH_WARNING_TEMP'] = {
        severity: 'WARNING',
        message: `⚠️ HIGH: Temperature ${temp.toFixed(1)}°C approaching critical level`,
        timestamp: new Date().toISOString()
      };
    } else if (temp > 26) {
      newAlarms['MEDIUM_TEMP'] = {
        severity: 'WARNING',
        message: `⚠️ WARNING: Temperature ${temp.toFixed(1)}°C is above normal range`,
        timestamp: new Date().toISOString()
      };
    } else if (temp < 16) {
      newAlarms['LOW_WARNING_TEMP'] = {
        severity: 'WARNING',
        message: `⚠️ LOW: Temperature ${temp.toFixed(1)}°C is below normal range`,
        timestamp: new Date().toISOString()
      };
    } else if (temp < 18) {
      newAlarms['LOW_TEMP'] = {
        severity: 'WARNING',
        message: `⚠️ COOL: Temperature ${temp.toFixed(1)}°C is below optimal range`,
        timestamp: new Date().toISOString()
      };
    }
    
    // INFO Alarms (Bilgi)
    else if (temp > 24) {
      newAlarms['WARM_INFO'] = {
        severity: 'INFO',
        message: `ℹ️ WARM: Temperature ${temp.toFixed(1)}°C is above optimal`,
        timestamp: new Date().toISOString()
      };
    } else if (temp < 20) {
      newAlarms['COOL_INFO'] = {
        severity: 'INFO',
        message: `ℹ️ COOL: Temperature ${temp.toFixed(1)}°C is below optimal`,
        timestamp: new Date().toISOString()
      };
    }
    
    setAlarms(newAlarms);
    
    if (Object.keys(newAlarms).length > 0) {
      console.log('🚨 Local temperature alarms detected:', newAlarms);
    }
  };





  // Fetch aircrafts from WebSocket data or database
  const fetchAircrafts = async () => {
    try {
      setLoading(true);
      console.log('🚀 Fetching aircrafts...');
      
      // First try to get aircrafts from WebSocket data
      if (websocketAircraftIds.size > 0) {
        console.log('📡 Using aircrafts from WebSocket:', Array.from(websocketAircraftIds));
        
        const websocketAircrafts: Aircraft[] = Array.from(websocketAircraftIds).map(id => {
          console.log(`🔍 Creating WebSocket aircraft for ID: ${id}`);
          
          // Extended static route mapping
          const staticRoutes: { [key: string]: string } = {
            'TC-CC3': 'IST-BKK',
            'TC-JJ0': 'IST-LHR',
            'TC-ABC': 'IST-CDG',
            'TC-DEF': 'IST-BER',
            'TC-GHI': 'IST-JFK',
            'TC-JKL': 'IST-NRT',
            'TC-MM3': 'IST-AMS',
            'TC-PQR': 'IST-FRA',
            'TC-STU': 'IST-MAD',
            'TC-VWX': 'IST-ARN',
            'TC-YZ1': 'IST-OSL',
            'TC-234': 'IST-CPH',
            'TC-567': 'IST-HEL',
            'TC-890': 'IST-WAW',
            'TC-MNO': 'IST-MXP',
            'TC-RST': 'IST-ATH',
            'TC-UVW': 'IST-LIS',
            'TC-XYZ': 'IST-OPO'
          };
          
          const route = staticRoutes[id] || `IST-${id.slice(-3)}`;
          console.log(`✅ Aircraft ${id} assigned route: ${route}`);
          
          return {
            id: id,
            registration: id,
            model: 'Aircraft (Live)',
            status: 'ACTIVE',
            currentTemperature: 22.0 + Math.random() * 6, // Random temp between 22-28°C
            cabinZone: 'MID',
            route: route,
            departure: 'IST',
            destination: route.split('-')[1] || 'Live',
            lastUpdate: new Date().toISOString(),
          };
        });
        
        setAircrafts(websocketAircrafts);
        setError('');
        return;
      }
      
      // Fallback to database API
      console.log('🔄 No WebSocket data, trying database...');
      
      let aircraftData: any[] = [];
      
      // Try multiple endpoints for better compatibility
      try {
        const response = await fetch(buildApiUrl(API_CONFIG.ENDPOINTS.AIRCRAFT_TEMPERATURES));
        if (response.ok) {
          aircraftData = await handleApiResponse(response);
          console.log('✅ Aircrafts fetched from aircraft-temperatures endpoint:', aircraftData);
        }
      } catch (error) {
        console.log('🔄 aircraft-temperatures endpoint failed, trying alternative...');
        console.error('Error details:', error);
      }
      
      // If no data, try alternative endpoint
      if (aircraftData.length === 0) {
        try {
          const response = await fetch(buildApiUrl(API_CONFIG.ENDPOINTS.AIRCRAFTS));
          if (response.ok) {
            aircraftData = await handleApiResponse(response);
            console.log('✅ Aircrafts fetched from aircrafts endpoint:', aircraftData);
          }
        } catch (error) {
          console.log('🔄 aircrafts endpoint also failed...');
          console.error('Error details:', error);
        }
      }
      
      if (aircraftData.length === 0) {
        throw new Error('No aircraft data available from any endpoint');
      }
      
      // Convert backend aircraft format to our format using API config
      const formattedAircrafts: Aircraft[] = aircraftData.map((aircraft: any) => {
        // Log the raw aircraft data to see what fields are available
        console.log('🔍 Raw aircraft data:', aircraft);
        console.log('🔍 Available fields in raw data:', Object.keys(aircraft));
        console.log('🔍 Route-related fields in raw data:', {
          route: aircraft.route,
          flightRoute: aircraft.flightRoute,
          flightPath: aircraft.flightPath,
          flightNumber: aircraft.flightNumber,
          routeName: aircraft.routeName,
          departure: aircraft.departure,
          destination: aircraft.destination
        });
        
        const formatted = {
          id: getFieldValue(aircraft, API_CONFIG.FIELD_MAPPINGS.AIRCRAFT.ID, `AC_${Date.now()}`),
          registration: getFieldValue(aircraft, API_CONFIG.FIELD_MAPPINGS.AIRCRAFT.REGISTRATION, 'UNKNOWN'),
          model: getFieldValue(aircraft, API_CONFIG.FIELD_MAPPINGS.AIRCRAFT.MODEL, API_CONFIG.DEFAULTS.AIRCRAFT.MODEL),
          status: getFieldValue(aircraft, API_CONFIG.FIELD_MAPPINGS.AIRCRAFT.STATUS, API_CONFIG.DEFAULTS.AIRCRAFT.STATUS),
          currentTemperature: getFieldValue(aircraft, API_CONFIG.FIELD_MAPPINGS.AIRCRAFT.TEMPERATURE, API_CONFIG.DEFAULTS.AIRCRAFT.TEMPERATURE),
          cabinZone: getFieldValue(aircraft, API_CONFIG.FIELD_MAPPINGS.AIRCRAFT.ZONE, API_CONFIG.DEFAULTS.AIRCRAFT.ZONE),
          route: getFieldValue(aircraft, API_CONFIG.FIELD_MAPPINGS.AIRCRAFT.ROUTE, API_CONFIG.DEFAULTS.AIRCRAFT.ROUTE),
          departure: getFieldValue(aircraft, API_CONFIG.FIELD_MAPPINGS.AIRCRAFT.DEPARTURE, undefined),
          destination: getFieldValue(aircraft, API_CONFIG.FIELD_MAPPINGS.AIRCRAFT.DESTINATION, undefined),
          lastUpdate: getFieldValue(aircraft, API_CONFIG.FIELD_MAPPINGS.AIRCRAFT.LAST_UPDATE, new Date().toISOString())
        };
        
        console.log('🔍 Formatted aircraft:', formatted);
        console.log('🔍 Route info in formatted data:', {
          route: formatted.route,
          departure: formatted.departure,
          destination: formatted.destination
        });
        return formatted;
      });
      
      setAircrafts(formattedAircrafts);
      setError('');
    } catch (error) {
      console.error('❌ Error fetching aircrafts:', error);
      console.log('🔄 No aircraft data available from backend');
      setAircrafts([]);
      setError('No aircraft data available from backend');
    } finally {
      setLoading(false);
    }
  };

  // Fetch aircrafts on component mount
  useEffect(() => {
    fetchAircrafts();
  }, []);

  // Auto-update aircraft list when new WebSocket aircraft IDs arrive
  useEffect(() => {
    if (websocketAircraftIds.size > 0) {
      fetchAircrafts();
    }
  }, [websocketAircraftIds]);

  // Fetch alarms when aircraft is selected
  useEffect(() => {
    if (selectedAircraft) {
      fetchAlarms(selectedAircraft.id);
      
      // Set selected aircraft route once when aircraft is selected
      if (selectedAircraft.route && selectedAircraft.route !== 'Unknown Route' && selectedAircraft.route !== 'WebSocket Route') {
        setSelectedAircraftRoute(selectedAircraft.route);
        console.log(`🎯 Selected aircraft route set to: ${selectedAircraft.route}`);
      }
    }
  }, [selectedAircraft]);

  // Analyze routes and zones
  const analyzeRoutesAndZones = useCallback(() => {
    if (aircrafts.length === 0) return;

    // Route Analysis
    const routeMap = new Map<string, { aircrafts: Aircraft[]; temps: number[] }>();
    
    aircrafts.forEach(aircraft => {
      // First try to get route from Aircraft interface directly
      let route = aircraft.route;
      
      // If no route in Aircraft interface, try API field mappings
      if (!route) {
        route = getFieldValue(aircraft, API_CONFIG.FIELD_MAPPINGS.AIRCRAFT.ROUTE, undefined);
      }
      
      // If still no route, try to construct from departure + destination
      if (!route) {
        const departure = aircraft.departure || getFieldValue(aircraft, API_CONFIG.FIELD_MAPPINGS.AIRCRAFT.DEPARTURE, 'Unknown');
        const destination = aircraft.destination || getFieldValue(aircraft, API_CONFIG.FIELD_MAPPINGS.AIRCRAFT.DESTINATION, 'Unknown');
        
        if (departure !== 'Unknown' && destination !== 'Unknown') {
          route = `${departure} - ${destination}`;
        } else if (destination !== 'Unknown') {
          route = `To ${destination}`;
        } else if (departure !== 'Unknown') {
          route = `From ${departure}`;
        } else {
          route = 'Unknown Route';
        }
      }
      
      // If this is the selected aircraft and we have a saved route, use it
      if (selectedAircraft && aircraft.id === selectedAircraft.id && selectedAircraftRoute) {
        route = selectedAircraftRoute;
        console.log(`🎯 Using saved route for selected aircraft: ${route}`);
      } else if (selectedAircraft && aircraft.id === selectedAircraft.id && aircraft.route && aircraft.route !== 'Unknown Route' && aircraft.route !== 'WebSocket Route') {
        // Use the aircraft's current route if it's valid
        route = aircraft.route;
        console.log(`🎯 Using current aircraft route for selected aircraft: ${route}`);
      }
      
      console.log(`🔍 Aircraft ${aircraft.registration}: Route = "${route}"`);
      console.log(`   - From interface: ${aircraft.route || 'undefined'}`);
      console.log(`   - From API mapping: ${getFieldValue(aircraft, API_CONFIG.FIELD_MAPPINGS.AIRCRAFT.ROUTE, 'N/A')}`);
      console.log(`   - Departure: ${aircraft.departure || 'undefined'}`);
      console.log(`   - Destination: ${aircraft.destination || 'undefined'}`);
      console.log(`   - Raw aircraft data:`, aircraft);
      
      if (!routeMap.has(route)) {
        routeMap.set(route, { aircrafts: [], temps: [] });
      }
      routeMap.get(route)!.aircrafts.push(aircraft);
      routeMap.get(route)!.temps.push(aircraft.currentTemperature);
    });

            const routeAnalysisData: RouteAnalysis[] = Array.from(routeMap.entries()).map(([route, data]) => {
          const avgTemp = data.temps.reduce((sum, temp) => sum + temp, 0) / data.temps.length;
          const trend = avgTemp > 26 ? 'INCREASING' : avgTemp < 20 ? 'DECREASING' : 'STABLE';
          const criticalZones = data.aircrafts.filter(a => a.currentTemperature > 28).map(a => a.cabinZone);
          
          return {
            routeId: route,
            routeName: route,
            aircraftCount: data.aircrafts.length,
            avgTemperature: avgTemp,
            temperatureTrend: trend,
            criticalZones: Array.from(new Set(criticalZones)),
            lastUpdate: new Date().toISOString()
          };
        });

    setRouteAnalysis(routeAnalysisData);

    // Zone Analysis
    const zoneData: { [key: string]: { temps: number[]; critical: number } } = { 
      FWD: { temps: [], critical: 0 }, 
      MID: { temps: [], critical: 0 }, 
      AFT: { temps: [], critical: 0 } 
    };
    
    aircrafts.forEach(aircraft => {
      const zone = getFieldValue(aircraft, API_CONFIG.FIELD_MAPPINGS.AIRCRAFT.ZONE, 'MID');
      if (zone in zoneData) {
        zoneData[zone].temps.push(aircraft.currentTemperature);
        if (aircraft.currentTemperature > 28) {
          zoneData[zone].critical++;
        }
      }
    });

    setZoneAnalysis({
      FWD: {
        avgTemp: zoneData.FWD.temps.length > 0 ? zoneData.FWD.temps.reduce((sum, temp) => sum + temp, 0) / zoneData.FWD.temps.length : 0,
        trend: zoneData.FWD.temps.length > 0 ? (zoneData.FWD.temps[zoneData.FWD.temps.length - 1] > 26 ? 'INCREASING' : zoneData.FWD.temps[zoneData.FWD.temps.length - 1] < 20 ? 'DECREASING' : 'STABLE') : 'STABLE',
        criticalCount: zoneData.FWD.critical
      },
      MID: {
        avgTemp: zoneData.MID.temps.length > 0 ? zoneData.MID.temps.reduce((sum, temp) => sum + temp, 0) / zoneData.MID.temps.length : 0,
        trend: zoneData.MID.temps.length > 0 ? (zoneData.MID.temps[zoneData.MID.temps.length - 1] > 26 ? 'INCREASING' : zoneData.MID.temps[zoneData.MID.temps.length - 1] < 20 ? 'DECREASING' : 'STABLE') : 'STABLE',
        criticalCount: zoneData.MID.critical
      },
      AFT: {
        avgTemp: zoneData.AFT.temps.length > 0 ? zoneData.AFT.temps.reduce((sum, temp) => sum + temp, 0) / zoneData.AFT.temps.length : 0,
        trend: zoneData.AFT.temps.length > 0 ? (zoneData.AFT.temps[zoneData.AFT.temps.length - 1] > 26 ? 'INCREASING' : zoneData.AFT.temps[zoneData.AFT.temps.length - 1] < 20 ? 'DECREASING' : 'STABLE') : 'STABLE',
        criticalCount: zoneData.AFT.critical
      }
    });

  }, [aircrafts]);

  // Analyze routes and zones when aircrafts change
  useEffect(() => {
    analyzeRoutesAndZones();
  }, [aircrafts, analyzeRoutesAndZones]);

  // Temperature to color mapping
  const getTemperatureColor = (temp: number) => {
    if (temp < 18) return '#4A90E2'; // Cold - Blue
    if (temp < 22) return '#7ED321'; // Cool - Green
    if (temp < 26) return '#F5A623'; // Warm - Orange
    if (temp < 30) return '#FF6B6B'; // Hot - Red
    return '#D0021B'; // Very Hot - Dark Red
  };

  // Get zone temperature based on aircraft data or WebSocket updates
  const getZoneTemperature = (zoneName: string, aircraft: Aircraft) => {
    // If we have real-time WebSocket data, use it
    if (zoneTemperatures[zoneName] !== undefined) {
      return zoneTemperatures[zoneName];
    }
    
    // Otherwise, simulate different temperatures for different zones
    const zoneMultipliers: { [key: string]: number } = {
      'FWD': 0.95, // Slightly cooler
      'MID': 1.0,  // Normal (base temperature)
      'AFT': 1.05, // Slightly warmer
    };
    
    const baseTemp = aircraft.currentTemperature;
    const multiplier = zoneMultipliers[zoneName] || 1.0;
    return baseTemp * multiplier;
  };

  // Update time-based heat map chart
  const updateTimeHeatMap = useCallback(() => {
    if (!heatmapChartRef.current || !selectedAircraft) return;

    const canvas = heatmapChartRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Use real-time data if available, otherwise fall back to sample data
    let timeLabels: string[] = [];
    let zoneData: {
      FWD: number[];
      MID: number[];
      AFT: number[];
    };

    if (realTimeData.FWD.length > 0) {
      // Use real-time data
      const dataLength = Math.min(realTimeData.FWD.length, 24); // Show last 24 readings
      const recentData = {
        FWD: realTimeData.FWD.slice(-dataLength),
        MID: realTimeData.MID.slice(-dataLength),
        AFT: realTimeData.AFT.slice(-dataLength)
      };

      timeLabels = recentData.FWD.map(item => 
        item.timestamp.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })
      );
      
      zoneData = {
        FWD: recentData.FWD.map(item => item.temp),
        MID: recentData.MID.map(item => item.temp),
        AFT: recentData.AFT.map(item => item.temp)
      };
    } else {
      // Fall back to sample data for the selected time range
      const start = new Date(startDate);
      const end = new Date(endDate);
      const timeRange = end.getTime() - start.getTime();
      const hours = Math.ceil(timeRange / (1000 * 60 * 60));

      timeLabels = [];
      zoneData = {
        FWD: [],
        MID: [],
        AFT: []
      };

      for (let i = 0; i < hours; i++) {
        const time = new Date(start.getTime() + i * 60 * 60 * 1000);
        timeLabels.push(time.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }));
        
        // Generate sample temperature data for each zone
        zoneData.FWD.push(20 + Math.random() * 10);
        zoneData.MID.push(22 + Math.random() * 8);
        zoneData.AFT.push(21 + Math.random() * 9);
      }
    }

    // Draw heat map
    const dataLength = zoneData.FWD.length;
    const cellWidth = canvas.width / dataLength;
    const cellHeight = canvas.height / 3;

    // Draw FWD zone (top row)
    zoneData.FWD.forEach((temp, index) => {
      const color = getTemperatureColor(temp);
      ctx.fillStyle = color;
      ctx.fillRect(index * cellWidth, 0, cellWidth, cellHeight);
      
      // Add temperature text
      ctx.fillStyle = 'white';
      ctx.font = 'bold 14px Arial';
      ctx.textAlign = 'center';
      ctx.fillText(`${temp.toFixed(1)}°C`, index * cellWidth + cellWidth/2, cellHeight/2 + 4);
    });

    // Draw MID zone (middle row)
    zoneData.MID.forEach((temp, index) => {
      const color = getTemperatureColor(temp);
      ctx.fillStyle = color;
      ctx.fillRect(index * cellWidth, cellHeight, cellWidth, cellHeight);
      
      // Add temperature text
      ctx.fillStyle = 'white';
      ctx.font = 'bold 14px Arial';
      ctx.textAlign = 'center';
      ctx.fillText(`${temp.toFixed(1)}°C`, index * cellWidth + cellWidth/2, cellHeight + cellHeight/2 + 4);
    });

    // Draw AFT zone (bottom row)
    zoneData.AFT.forEach((temp, index) => {
      const color = getTemperatureColor(temp);
      ctx.fillStyle = color;
      ctx.fillRect(index * cellWidth, cellHeight * 2, cellWidth, cellHeight);
      
      // Add temperature text
      ctx.fillStyle = 'white';
      ctx.font = 'bold 14px Arial';
      ctx.textAlign = 'center';
      ctx.fillText(`${temp.toFixed(1)}°C`, index * cellWidth + cellWidth/2, cellHeight * 2 + cellHeight/2 + 4);
    });

    // Draw zone labels
    ctx.fillStyle = 'black';
    ctx.font = 'bold 18px Arial';
    ctx.textAlign = 'left';
    ctx.fillText('FWD', 15, cellHeight/2 + 4);
    ctx.fillText('MID', 15, cellHeight + cellHeight/2 + 4);
    ctx.fillText('AFT', 15, cellHeight * 2 + cellHeight/2 + 4);

    // Draw time labels
    ctx.fillStyle = 'black';
    ctx.font = 'bold 14px Arial';
    ctx.textAlign = 'center';
    timeLabels.forEach((label, index) => {
      if (index % 2 === 0) { // Show every 2nd label to avoid crowding
        ctx.fillText(label, index * cellWidth + cellWidth/2, canvas.height - 8);
      }
    });

  }, [startDate, endDate, selectedAircraft, getTemperatureColor]);

  // Auto-update chart when dates change or real-time data updates
  useEffect(() => {
    if (selectedAircraft && startDate && endDate) {
      updateTimeHeatMap();
    }
  }, [selectedAircraft, startDate, endDate, updateTimeHeatMap, realTimeData]);

  // Auto-refresh chart every 2 seconds when real-time data is available
  useEffect(() => {
    if (realTimeData.FWD.length > 0) {
      const interval = setInterval(() => {
        updateTimeHeatMap();
      }, 2000); // Update every 2 seconds

      return () => clearInterval(interval);
    }
  }, [realTimeData, updateTimeHeatMap]);

  // Handle zone click
  const handleZoneClick = (zoneName: string) => {
    if (selectedAircraft) {
      const zoneTemp = getZoneTemperature(zoneName, selectedAircraft);
      console.log(`🌡️ ${zoneName} Zone Temperature: ${zoneTemp.toFixed(1)}°C`);
      
      // Show zone details and any active alarms
      if (alarms[zoneName]) {
        console.log(`🚨 ${zoneName} Zone Alarm:`, alarms[zoneName]);
      }
    }
  };

  if (loading) {
    return (
      <div className="heatmap-loading">
        <div className="loading-spinner"></div>
        <p>Loading Heat Map...</p>
      </div>
    );
  }

  return (
    <div className="heatmap-view">


      {/* Error Display */}
      {error && (
        <div className="error-panel">
          <span className="error-icon">⚠️</span>
          <span className="error-message">{error}</span>
        </div>
      )}

      {selectedAircraft && (
        <div className="aircraft-info-panel">
          <h2>✈️ {selectedAircraft.registration}</h2>
          <div className="info-grid">
            <div className="info-item">
              <span className="label">Model:</span>
              <span className="value">{selectedAircraft.model}</span>
            </div>
            <div className="info-item">
              <span className="label">Status:</span>
              <span className={`status-badge status-${selectedAircraft.status.toLowerCase()}`}>
                {selectedAircraft.status}
              </span>
            </div>

            <div className="info-item">
              <span className="label">Last Update:</span>
              <span className="value">{lastUpdate.toLocaleString()}</span>
            </div>
            <div className="info-item">
              <span className="label">Route:</span>
              <span className="value">
                {(() => {
                  console.log('🔍 Selected Aircraft ID:', selectedAircraft?.id);
                  console.log('🔍 Selected Aircraft:', selectedAircraft);
                  
                  // Extended static route mapping for all aircraft IDs
                  const staticRoutes: { [key: string]: string } = {
                    'TC-CC3': 'IST-BKK',
                    'TC-JJ0': 'IST-LHR',
                    'TC-ABC': 'IST-CDG',
                    'TC-DEF': 'IST-BER',
                    'TC-GHI': 'IST-JFK',
                    'TC-JKL': 'IST-NRT',
                    'TC-MM3': 'IST-AMS',
                    'TC-PQR': 'IST-FRA',
                    'TC-STU': 'IST-MAD',
                    'TC-VWX': 'IST-ARN',
                    'TC-YZ1': 'IST-OSL',
                    'TC-234': 'IST-CPH',
                    'TC-567': 'IST-HEL',
                    'TC-890': 'IST-WAW',
                    'TC-MNO': 'IST-MXP',
                    'TC-RST': 'IST-ATH',
                    'TC-UVW': 'IST-LIS',
                    'TC-XYZ': 'IST-OPO'
                  };
                  
                  // Check static routes first
                  if (selectedAircraft?.id && staticRoutes[selectedAircraft.id]) {
                    console.log(`✅ Using static route for ${selectedAircraft.id}: ${staticRoutes[selectedAircraft.id]}`);
                    return staticRoutes[selectedAircraft.id];
                  }
                  
                  // Check if aircraft has route from WebSocket or database
                  if (selectedAircraft?.id) {
                    const aircraft = aircrafts.find(a => a.id === selectedAircraft.id);
                    console.log(`🔍 Found aircraft in aircrafts array:`, aircraft);
                    console.log(`🔍 Aircraft route: ${aircraft?.route}`);
                    
                    if (aircraft?.route && aircraft.route !== 'Unknown Route' && aircraft.route !== 'WebSocket Route' && aircraft.route !== 'Live Route') {
                      console.log(`✅ Using aircraft route: ${aircraft.route}`);
                      return aircraft.route;
                    }
                  }
                  
                  // Fallback: Generate route from aircraft ID if no static route found
                  if (selectedAircraft?.id) {
                    const fallbackRoute = `IST-${selectedAircraft.id.slice(-3)}`;
                    console.log(`🔄 Generated fallback route for ${selectedAircraft.id}: ${fallbackRoute}`);
                    return fallbackRoute;
                  }
                  
                  console.log(`❌ No route found for ${selectedAircraft?.id}, showing Unknown Route`);
                  return 'Unknown Route';
                })()}
              </span>
            </div>
            <div className="info-item">
              <span className="label">Database Status:</span>
              <span className="value">
                {loading ? '🔄 Loading...' : error ? '❌ Error' : '✅ Connected'}
              </span>
            </div>
          </div>
          
          {/* Real-time Update Indicator */}
          <div className="realtime-indicator">
            <span className="indicator-dot"></span>
            <span className="indicator-text">Real-time Updates Active</span>
          </div>
        </div>
      )}





      {/* Temperature Legend */}
      <div className="temperature-legend">
        <h3>Temperature Scale</h3>
        <div className="legend-items">
          <div className="legend-item">
            <div className="legend-color" style={{ backgroundColor: '#4A90E2' }}></div>
            <span>&lt; 18°C (Cold)</span>
          </div>
          <div className="legend-item">
            <div className="legend-color" style={{ backgroundColor: '#7ED321' }}></div>
            <span>18-22°C (Cool)</span>
          </div>
          <div className="legend-item">
            <div className="legend-color" style={{ backgroundColor: '#F5A623' }}></div>
            <span>22-26°C (Warm)</span>
          </div>
          <div className="legend-item">
            <div className="legend-color" style={{ backgroundColor: '#FF6B6B' }}></div>
            <span>26-30°C (Hot)</span>
          </div>
          <div className="legend-item">
            <div className="legend-color" style={{ backgroundColor: '#D0021B' }}></div>
            <span>&gt; 30°C (Very Hot)</span>
          </div>
        </div>
      </div>

      {/* Zone Details */}
      {selectedAircraft && (
        <div className="zone-details">
          <h3>Zone Temperature Details</h3>
          <div className="zone-grid">
            {aircraftZones.map((zone, index) => {
              const zoneTemp = getZoneTemperature(zone.name, selectedAircraft);
              const tempColor = getTemperatureColor(zoneTemp);
              const hasAlarm = alarms[zone.name];
              
              return (
                <div key={index} className={`zone-detail-item ${hasAlarm ? 'has-alarm' : ''}`}>
                  <div className="zone-detail-header">
                    <span className="zone-name">{zone.name}</span>
                    <div 
                      className="zone-temp-indicator" 
                      style={{ backgroundColor: tempColor }}
                    ></div>
                    {hasAlarm && <span className="alarm-badge">🚨</span>}
                  </div>
                  <div className="zone-temp-value">{zoneTemp.toFixed(1)}°C</div>
                  <div className="zone-status">
                    {zoneTemp < 18 ? '❄️ Cold' : 
                     zoneTemp < 22 ? '🌤️ Cool' : 
                     zoneTemp < 26 ? '🌡️ Normal' : 
                     zoneTemp < 30 ? '🔥 Warm' : '🚨 Hot'}
                  </div>
                  {hasAlarm && (
                    <div className="zone-alarm-message">
                      {hasAlarm.message}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}



      {/* Active Alarms Panel - Always Visible */}
      <div className={`alarms-panel ${Object.keys(alarms).length > 0 ? 'has-alarms' : 'no-alarms'}`}>
        <div className="alarm-left-section">
          <h3>
            {Object.keys(alarms).length > 0 ? '🚨 Active Temperature Alarms' : '🔔 No Active Alarms'}
          </h3>
          <div className="alarm-source-info">
            📡 Alarms from backend API - Real-time updates
          </div>
        </div>
        
        <div className="alarm-center-section">
          <div className="alarm-rules-info">
            <button 
              className="rules-button"
              onClick={() => setShowRulesModal(true)}
            >
              📋 Alarm Rules & Thresholds
            </button>
          </div>
        </div>
        
        <div className="alarm-right-section">
          <div className="alarms-grid">
            {Object.keys(alarms).length > 0 ? (
              Object.entries(alarms).map(([key, alarm]) => (
                <div key={key} className={`alarm-item severity-${alarm.severity.toLowerCase()}`}>
                  <div className="alarm-header">
                    <span className="alarm-severity">{alarm.severity}</span>
                    <span className="alarm-time">
                      {alarm.timestamp ? new Date(alarm.timestamp).toLocaleTimeString() : new Date().toLocaleTimeString()}
                    </span>
                  </div>
                  <div className="alarm-message">{alarm.message}</div>
                </div>
              ))
            ) : (
              <div className="no-alarms-message">
                <span className="no-alarms-icon">✅</span>
                <span className="no-alarms-text">All temperature readings are within normal range</span>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="heatmap-container">
        <div className="aircraft-outline">
          {/* Aircraft body */}
                              <div className="aircraft-body">
            {/* Zones */}
            {aircraftZones.map((zone, index) => {
              const zoneTemp = selectedAircraft ? getZoneTemperature(zone.name, selectedAircraft) : 20;
              const tempColor = getTemperatureColor(zoneTemp);
              
              return (
                <div
                  key={index}
                  className="zone"
                  data-zone={zone.name}
                  style={{
                    left: `${zone.x}%`,
                    top: `${zone.y}%`,
                    width: `${zone.width}%`,
                    height: `${zone.height}%`,
                    backgroundColor: tempColor,
                    opacity: selectedAircraft ? 0.9 : 0.4,
                  }}
                  onClick={() => handleZoneClick(zone.name)}
                  title={`${zone.name}: ${zoneTemp.toFixed(1)}°C`}
                >
                  <div className="zone-label">{zone.name}</div>
                  {selectedAircraft && (
                    <div className="zone-temperature">{zoneTemp.toFixed(1)}°C</div>
                  )}
                </div>
              );
            })}
            

          </div>
          
          {/* Aircraft details */}
          <div className="aircraft-details">
            <div className="nose">Nose</div>
            <div className="tail">Tail</div>
            <div className="wing-left">Left Wing</div>
            <div className="wing-right">Right Wing</div>
          </div>
        </div>
      </div>
     

      {/* Time-based Heat Map Chart */}
      {selectedAircraft && (
                  <div className="time-heatmap-chart">
            <h3>
              {realTimeData.FWD.length > 0 ? '🔥 Real-time Temperature Heat Map' : '📊 Time-based Temperature Heat Map'}
            </h3>

          
          {/* Date Range Selector */}
          <div className="date-range-selector">
            <div className="date-input-group">
              <label>Start Date:</label>
              <input 
                type="datetime-local" 
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="date-input"
              />
            </div>
            <div className="date-input-group">
              <label>End Date:</label>
              <input 
                type="datetime-local" 
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="date-input"
              />
            </div>
            <button 
              className="update-chart-btn"
              onClick={updateTimeHeatMap}
            >
              Update Chart
            </button>
          </div>

          {/* Heat Map Chart */}
          <div className="heatmap-chart-container">
            <canvas ref={heatmapChartRef} width="1200" height="500"></canvas>
          </div>
        </div>
      )}

      {/* Alarm Rules Modal */}
      {showRulesModal && (
        <div className="modal-overlay" onClick={() => setShowRulesModal(false)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h2>📋 Alarm Rules & Thresholds</h2>
              <button 
                className="modal-close-btn"
                onClick={() => setShowRulesModal(false)}
              >
                ✕
              </button>
            </div>
            <div className="modal-body">
              <div className="rules-grid">
                <div className="rule-item critical">
                  <span className="rule-severity">🚨 CRITICAL</span>
                  <span className="rule-threshold">&gt; 30°C</span>
                  <span className="rule-desc">Immediate action required</span>
                </div>
                <div className="rule-item warning">
                  <span className="rule-severity">⚠️ WARNING</span>
                  <span className="rule-threshold">26-30°C / 16-18°C</span>
                  <span className="rule-desc">Above/below normal range</span>
                </div>
                <div className="rule-item info">
                  <span className="rule-severity">ℹ️ INFO</span>
                  <span className="rule-threshold">20-24°C</span>
                  <span className="rule-desc">Optimal temperature range</span>
                </div>
                <div className="rule-item normal">
                  <span className="rule-severity">✅ NORMAL</span>
                  <span className="rule-threshold">18-26°C</span>
                  <span className="rule-desc">Safe operating range</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
});

export default HeatMapView;
