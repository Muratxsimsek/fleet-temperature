import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { Line, Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import axios from 'axios';
import './AircraftDashboard.css';
import { API_CONFIG, getFieldValue, buildApiUrl, handleApiResponse, parseWrapperResponse } from '../config/api';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend
);

interface Aircraft {
  id: string;
  registration: string;
  model: string;
  status: 'ACTIVE' | 'MAINTENANCE' | 'GROUNDED';
  currentTemperature: number;
  cabinZone: string;
  lastUpdate: string;
}

interface TemperatureReading {
  id: number;
  aircraftId: string;
  messageId?: string;
  cabinZone: string;
  temperatureCelsius: number;
  temperatureFahrenheit: number;
  status: 'NORMAL' | 'WARNING' | 'CRITICAL';
  timestamp: string;
  notes?: string;
  createdAt?: string;
}

interface TemperatureAlarm {
  id: string;
  aircraftId: string;
  severity: 'LOW' | 'MEDIUM' | 'HIGH';
  description: string;
  triggeredAt: string;
  resolved: boolean;
}

interface AircraftDashboardProps {
  stompClient: any;
  isConnected: boolean;
}

// API_BASE_URL is now handled by API_CONFIG

const AircraftDashboard: React.FC<AircraftDashboardProps> = React.memo(({ stompClient, isConnected }) => {
  const [aircrafts, setAircrafts] = useState<Aircraft[]>([]);
  const [alarms, setAlarms] = useState<TemperatureAlarm[]>([]);
  const [aircraftHistory, setAircraftHistory] = useState<TemperatureReading[]>([]);
  const [selectedAircraftId, setSelectedAircraftId] = useState<string | null>(null);
  const [showHistoryModal, setShowHistoryModal] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [lastUpdate, setLastUpdate] = useState(new Date());
  const [lastUpdateDisplay, setLastUpdateDisplay] = useState(new Date());
  
  // Real-time chart için state'ler
  const [chartTimeRange, setChartTimeRange] = useState<'1h' | '6h' | '24h' | '7d'>('1h');
  const [isRealTimeMode, setIsRealTimeMode] = useState(true);
  const [chartData, setChartData] = useState<TemperatureReading[]>([]);

  // Message queue system for performance optimization
  const messageQueueRef = useRef<{
    temperatureUpdates: TemperatureReading[];
    alarms: TemperatureAlarm[];
    statusUpdates: any[];
  }>({
    temperatureUpdates: [],
    alarms: [],
    statusUpdates: []
  });

  const batchTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const isProcessingRef = useRef(false);
  const lastProcessTimeRef = useRef(0);
  const subscriptionsRef = useRef<{ [key: string]: any }>({});
  const lastUpdateRef = useRef(new Date());

  // Performance tuning constants
  const CPU_THROTTLE_MS = 100; // Minimum 100ms between processing
  const BATCH_DELAY_MS = 500; // 500ms batch delay for faster updates

  // Process message queue with CPU throttling
  const processMessageQueue = useCallback(() => {
    if (isProcessingRef.current) return;
    
    const now = Date.now();
    if (now - lastProcessTimeRef.current < CPU_THROTTLE_MS) {
      setTimeout(processMessageQueue, CPU_THROTTLE_MS);
      return;
    }
    
    isProcessingRef.current = true;
    lastProcessTimeRef.current = now;
    
    const queue = messageQueueRef.current;
    let hasUpdates = false;
    
    // Batch temperature updates
    if (queue.temperatureUpdates.length > 0) {
      const updates = [...queue.temperatureUpdates];
      queue.temperatureUpdates = [];
      
      setAircrafts(prev => {
        const updated = [...prev];
        console.log('🔄 Processing temperature updates:', updates.length);
        updates.forEach(update => {
          const index = updated.findIndex(ac => ac.id === update.aircraftId);
          console.log(`🔍 Update for ${update.aircraftId}: found at index ${index}`);
          if (index >= 0) {
            updated[index] = {
              ...updated[index],
              currentTemperature: update.temperatureCelsius,
              lastUpdate: update.timestamp,
              cabinZone: update.cabinZone || updated[index].cabinZone
            };
            console.log(`✅ Updated aircraft ${update.aircraftId}: temp=${update.temperatureCelsius}°C`);
          } else {
            console.log(`❌ Aircraft ${update.aircraftId} not found, creating new aircraft`);
            // Create new aircraft if it doesn't exist
            const newAircraft: Aircraft = {
              id: update.aircraftId,
              registration: update.aircraftId, // Use aircraftId as registration for now
              model: 'Unknown Model',
              status: 'ACTIVE',
              currentTemperature: update.temperatureCelsius,
              cabinZone: update.cabinZone || 'Unknown Zone',
              lastUpdate: update.timestamp
            };
            updated.push(newAircraft);
            console.log(`🆕 Created new aircraft: ${update.aircraftId}`);
          }
        });
        return updated;
      });
      
      // Update aircraft history for selected aircraft
      if (selectedAircraftId) {
        const relevantUpdates = updates.filter(u => u.aircraftId === selectedAircraftId);
        if (relevantUpdates.length > 0) {
          setAircraftHistory(prev => {
            const newHistory = [...prev, ...relevantUpdates];
            return newHistory.slice(-20); // Keep only last 20 readings
          });
        }
      }
      
      hasUpdates = true;
    }
    
    // Batch alarm updates
    if (queue.alarms.length > 0) {
      const newAlarms = [...queue.alarms];
      queue.alarms = [];
      
      setAlarms(prev => {
        const updated = [...prev];
        newAlarms.forEach(alarm => {
          const existingIndex = updated.findIndex(a => a.id === alarm.id);
          if (existingIndex >= 0) {
            updated[existingIndex] = alarm;
          } else {
            updated.unshift(alarm);
          }
        });
        return updated.slice(0, 50); // Keep only last 50 alarms
      });
      
      hasUpdates = true;
    }
    
    // Batch status updates
    if (queue.statusUpdates.length > 0) {
      const statusUpdates = [...queue.statusUpdates];
      queue.statusUpdates = [];
      
      setAircrafts(prev => {
        const updated = [...prev];
        statusUpdates.forEach(update => {
          const index = updated.findIndex(ac => ac.id === update.aircraftId);
          if (index >= 0) {
            updated[index] = { ...updated[index], ...update };
          }
        });
        return updated;
      });
      
      hasUpdates = true;
    }
    
    if (hasUpdates) {
      // Throttle lastUpdate to reduce re-renders
      const now = new Date();
      lastUpdateRef.current = now;
      
      // Only update display every 2 seconds
      if (now.getTime() - lastUpdateDisplay.getTime() > 2000) {
        setLastUpdateDisplay(now);
      }
      
      console.log('🚀 Batch processed:', {
        temperatures: queue.temperatureUpdates.length,
        alarms: queue.alarms.length,
        statuses: queue.statusUpdates.length
      });
      
      // Performance monitoring
      console.log('⚡ Performance metrics:', {
        timestamp: now.toISOString(),
        queueSize: messageQueueRef.current.temperatureUpdates.length + 
                  messageQueueRef.current.alarms.length + 
                  messageQueueRef.current.statusUpdates.length,
        processingTime: Date.now() - performance.now()
      });
    }
    
    isProcessingRef.current = false;
  }, [selectedAircraftId, lastUpdateDisplay]);

  // Queue message for batch processing
  const queueMessage = useCallback((type: 'temperature' | 'alarm' | 'status' | 'alarm-resolve', data: any) => {
    switch (type) {
      case 'temperature':
        messageQueueRef.current.temperatureUpdates.push(data);
        // Temperature updates için hemen işle (critical data)
        if (messageQueueRef.current.temperatureUpdates.length >= 3) {
          if (batchTimeoutRef.current) {
            clearTimeout(batchTimeoutRef.current);
          }
          batchTimeoutRef.current = setTimeout(() => {
            processMessageQueue();
          }, 200); // Sadece 200ms bekle
          return;
        }
        break;
      case 'alarm':
        messageQueueRef.current.alarms.push(data);
        break;
      case 'status':
        messageQueueRef.current.statusUpdates.push(data);
        break;
      case 'alarm-resolve':
        // Handle alarm resolution immediately for better UX
        setAlarms(prev => prev.map(alarm =>
          alarm.id === data.alarmId ? { ...alarm, resolved: true } : alarm
        ));
        setLastUpdate(new Date());
        console.log('🔔 Alarm resolved via queue:', data.alarmId);
        return;
    }
    
    if (batchTimeoutRef.current) {
      clearTimeout(batchTimeoutRef.current);
    }
    
    batchTimeoutRef.current = setTimeout(() => {
      processMessageQueue();
    }, BATCH_DELAY_MS);
  }, [processMessageQueue]);

  // Cleanup WebSocket subscriptions
  const cleanupSubscriptions = useCallback(() => {
    Object.values(subscriptionsRef.current).forEach(subscription => {
      if (subscription && subscription.unsubscribe) {
        subscription.unsubscribe();
      }
    });
    subscriptionsRef.current = {};
    console.log('🧹 All WebSocket subscriptions cleaned up');
  }, []);

  // Setup WebSocket subscriptions
  const setupWebSocketSubscriptions = useCallback(() => {
    if (!stompClient || !isConnected) {
      console.log('⚠️ Cannot setup subscriptions: stompClient or connection not ready');
      return;
    }

    console.log('🔌 Setting up WebSocket subscriptions...');

    // Temperature updates subscription
    const tempSubscription = stompClient.subscribe('/topic/temperature-updates', (message: any) => {
      try {
        const tempReading: TemperatureReading = JSON.parse(message.body);
        console.log('🌡️ WebSocket Temperature Update:', tempReading);
        console.log('🔍 Current Aircraft IDs in UI:', aircrafts.map(a => a.id));
        console.log('🎯 Incoming aircraftId:', tempReading.aircraftId);
        console.log('📊 Total aircrafts in UI:', aircrafts.length);
        
        // Check if this aircraft exists in current UI state
        const existingAircraft = aircrafts.find(a => a.id === tempReading.aircraftId);
        if (existingAircraft) {
          console.log('✅ Aircraft found in UI:', existingAircraft.registration);
          console.log('📊 Current aircraft data:', existingAircraft);
        } else {
          console.log('❌ Aircraft NOT found in UI - will be created automatically');
          console.log('🔍 This suggests:');
          console.log('   - Backend has different aircraft IDs than UI');
          console.log('   - WebSocket is sending data for new aircraft');
          console.log('   - Aircraft will be auto-created in UI');
        }
        
        queueMessage('temperature', tempReading);
      } catch (error) {
        console.error('❌ Error parsing temperature update:', error);
        console.error('Raw message body:', message.body);
      }
    });
    subscriptionsRef.current['temperature'] = tempSubscription;
    console.log('✅ Subscribed to /topic/temperature-updates');

    // Alarm updates subscription
    const alarmSubscription = stompClient.subscribe('/topic/temperature-alarms', (message: any) => {
      try {
        const alarm: TemperatureAlarm = JSON.parse(message.body);
        queueMessage('alarm', alarm);
      } catch (error) {
        console.error('❌ Error parsing alarm update:', error);
        console.error('Raw message body:', message.body);
      }
    });
    subscriptionsRef.current['alarms'] = alarmSubscription;
    console.log('✅ Subscribed to /topic/temperature-alarms');

    // Aircraft status updates subscription
    const statusSubscription = stompClient.subscribe('/topic/aircraft-status', (message: any) => {
      try {
        const statusUpdate = JSON.parse(message.body);
        queueMessage('status', statusUpdate);
      } catch (error) {
        console.error('❌ Error parsing status update:', error);
        console.error('Raw message body:', message.body);
      }
    });
    subscriptionsRef.current['aircraft-status'] = statusSubscription;
    console.log('✅ Subscribed to /topic/aircraft-status');

    console.log('🎯 All WebSocket subscriptions setup complete');
  }, [stompClient, isConnected, cleanupSubscriptions]);

  // WebSocket güncellemelerini simüle et (test için)
  const simulateWebSocketUpdates = useCallback(() => {
    console.log('🧪 Simulating WebSocket updates for testing...');
    
    // Her 5 saniyede bir sıcaklık güncellemesi
    const tempInterval = setInterval(() => {
      const randomAircraft = aircrafts[Math.floor(Math.random() * aircrafts.length)];
      if (randomAircraft) {
        const tempUpdate: TemperatureReading = {
          id: Date.now(),
          aircraftId: randomAircraft.id,
          messageId: `MSG_${Date.now()}`,
          cabinZone: randomAircraft.cabinZone,
          temperatureCelsius: 18 + Math.random() * 15, // 18-33°C arası
          temperatureFahrenheit: (18 + Math.random() * 15) * 9/5 + 32,
          status: 'NORMAL' as const,
          timestamp: new Date().toISOString(),
          notes: 'Simulated temperature reading',
          createdAt: new Date().toISOString()
        };
        
        // Queue message for batch processing
        queueMessage('temperature', tempUpdate);
      }
    }, 5000); // 5s interval (daha hızlı test için)

    // Her 10 saniyede bir alarm güncellemesi
    const alarmInterval = setInterval(() => {
      const randomAircraft = aircrafts[Math.floor(Math.random() * aircrafts.length)];
      if (randomAircraft && Math.random() > 0.7) { // %30 ihtimalle alarm
        const alarm: TemperatureAlarm = {
          id: `ALM_${Date.now()}`,
          aircraftId: randomAircraft.id,
          severity: ['LOW', 'MEDIUM', 'HIGH'][Math.floor(Math.random() * 3)] as 'LOW' | 'MEDIUM' | 'HIGH',
          description: 'Simulated temperature alert',
          triggeredAt: new Date().toISOString(),
          resolved: false
        };
        
        // Queue message for batch processing
        queueMessage('alarm', alarm);
      }
    }, 10000); // 10s interval (daha hızlı test için)

    // Her 15 saniyede bir aircraft status güncellemesi
    const statusInterval = setInterval(() => {
      const randomAircraft = aircrafts[Math.floor(Math.random() * aircrafts.length)];
      if (randomAircraft && Math.random() > 0.8) { // %20 ihtimalle status değişikliği
        const newStatus = ['ACTIVE', 'MAINTENANCE', 'GROUNDED'][Math.floor(Math.random() * 3)] as 'ACTIVE' | 'MAINTENANCE' | 'GROUNDED';
        
        // Queue status update for batch processing
        queueMessage('status', { aircraftId: randomAircraft.id, status: newStatus });
      }
    }, 15000); // 15s interval (daha hızlı test için)

    // Cleanup function
    return () => {
      clearInterval(tempInterval);
      clearInterval(alarmInterval);
      clearInterval(statusInterval);
    };
  }, [stompClient, isConnected, aircrafts, queueMessage]);

  // Simulation'ı aircrafts yüklendiğinde başlat
  useEffect(() => {
    if (aircrafts.length > 0) {
      console.log('🚀 Starting WebSocket simulation...');
      const cleanup = simulateWebSocketUpdates();
      
      return cleanup;
    }
  }, [aircrafts.length, simulateWebSocketUpdates]);

  // Cleanup batch processing on unmount
  useEffect(() => {
    return () => {
      if (batchTimeoutRef.current) {
        clearTimeout(batchTimeoutRef.current);
      }
      // Process any remaining messages before unmount
      processMessageQueue();
    };
  }, [processMessageQueue]);

  const fetchAircrafts = async () => {
    try {
      setLoading(true);
      console.log('🚀 Fetching aircrafts from backend...');
      const response = await axios.get(buildApiUrl(API_CONFIG.ENDPOINTS.AIRCRAFT_TEMPERATURES));
      console.log('✅ Backend aircrafts received:', response.data);
      
      // Handle wrapper response format
      const aircraftData = parseWrapperResponse(response.data);
      console.log('🔍 Parsed aircraft data:', aircraftData);
      console.log('🔍 Backend Aircraft IDs:', aircraftData.data.map((a: any) => a.id));
      setAircrafts(aircraftData.data);
      setError('');
    } catch (err) {
      console.error('❌ Error fetching aircrafts from backend:', err);
      console.log('🔄 No aircraft data available from backend');
      setAircrafts([]);
      setError('No aircraft data available from backend');
    } finally {
      setLoading(false);
    }
  };

  const fetchAlarms = async () => {
    try {
      const response = await axios.get(buildApiUrl(API_CONFIG.ENDPOINTS.ACTIVE_ALARMS));
      const alarmData = parseWrapperResponse(response.data);
      setAlarms(alarmData.data);
    } catch (err) {
      console.error('Error fetching alarms:', err);
      console.log('🔄 No alarm data available from backend');
      setAlarms([]);
    }
  };

  const fetchAircraftHistory = async (aircraftId: string) => {
    try {
      const response = await axios.get(buildApiUrl(API_CONFIG.ENDPOINTS.AIRCRAFT_HISTORY, { id: aircraftId }) + '?hours=24');
      const historyData = parseWrapperResponse(response.data);
      setAircraftHistory(historyData.data);
    } catch (err) {
      console.error('Error fetching aircraft history:', err);
      console.log('🔄 No history data available from backend');
      setAircraftHistory([]);
    }
  };

  const handleAircraftSelect = useCallback((aircraftId: string) => {
    setSelectedAircraftId(aircraftId);
    fetchAircraftHistory(aircraftId);
    setShowHistoryModal(true);
  }, []);

  const closeHistoryModal = useCallback(() => {
    setShowHistoryModal(false);
    setSelectedAircraftId(null);
  }, []);

  const resolveAlarm = async (alarmId: string) => {
    try {
      await axios.post(buildApiUrl('/api/alarms/:id/resolve', { id: alarmId }));
      console.log('🔔 Alarm resolved via API:', alarmId);
      
      // Queue immediate UI update
      queueMessage('alarm-resolve', { alarmId });
    } catch (error) {
      console.error('Error resolving alarm:', error);
    }
  };

  // Memoized summary data to prevent unnecessary recalculations
  const summaryData = useMemo(() => {
    const totalAircraft = aircrafts.length;
    const activeAlarms = alarms.filter(a => !a.resolved).length;
    const criticalStatus = aircrafts.filter(a => a.status === 'MAINTENANCE' || a.status === 'GROUNDED').length;
    
    return { totalAircraft, activeAlarms, criticalStatus };
  }, [aircrafts, alarms]);

  // Memoized fleet status data
  const fleetStatusData = useMemo(() => {
    const statusCounts = aircrafts.reduce((acc, aircraft) => {
      acc[aircraft.status] = (acc[aircraft.status] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);
    
    return {
      labels: Object.keys(statusCounts),
      datasets: [{
        label: 'Aircraft Status',
        data: Object.values(statusCounts),
        backgroundColor: [
          'rgba(75, 192, 192, 0.6)',
          'rgba(255, 206, 86, 0.6)',
          'rgba(255, 99, 132, 0.6)'
        ],
        borderColor: [
          'rgba(75, 192, 192, 1)',
          'rgba(255, 206, 86, 1)',
          'rgba(255, 99, 132, 1)'
        ],
        borderWidth: 1
      }]
    };
  }, [aircrafts]);

  // Real-time chart data için useEffect
  useEffect(() => {
    if (selectedAircraftId && isRealTimeMode) {
      // WebSocket'ten gelen real-time data'yı chart'a ekle
      const relevantUpdates = aircraftHistory.filter(h => h.aircraftId === selectedAircraftId);
      
      // Zaman aralığına göre filtrele
      const now = new Date();
      const timeRangeMs = {
        '1h': 60 * 60 * 1000,
        '6h': 6 * 60 * 60 * 1000,
        '24h': 24 * 60 * 60 * 1000,
        '7d': 7 * 24 * 60 * 60 * 1000
      };
      
      const filteredData = relevantUpdates.filter(h => 
        now.getTime() - new Date(h.timestamp).getTime() <= timeRangeMs[chartTimeRange]
      );
      
      // Zamana göre sırala (eski → yeni)
      const sortedData = filteredData.sort((a, b) => 
        new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
      );
      
      setChartData(sortedData);
    }
  }, [aircraftHistory, selectedAircraftId, isRealTimeMode, chartTimeRange]);

  // Memoized temperature history data for charts
  const temperatureHistoryData = useMemo(() => {
    if (!chartData.length) return null;
    
    return {
      labels: chartData.map(h => new Date(h.timestamp).toLocaleTimeString()),
      datasets: [{
        label: 'Temperature (°C)',
        data: chartData.map(h => h.temperatureCelsius),
        borderColor: 'rgb(75, 192, 192)',
        backgroundColor: 'rgba(75, 192, 192, 0.1)',
        tension: 0.1,
        pointRadius: 0 // Hide points for better performance
      }]
    };
  }, [chartData]);

  // Ana WebSocket subscription'larını kur
  useEffect(() => {
    setupWebSocketSubscriptions();
    
    return () => {
      cleanupSubscriptions();
    };
  }, [setupWebSocketSubscriptions, cleanupSubscriptions]);

  // Initial data loading
  useEffect(() => {
    fetchAircrafts();
    fetchAlarms();
  }, []);

  // Test buttons for manual testing
  const testTemperatureUpdate = () => {
    if (aircrafts.length > 0) {
      const randomAircraft = aircrafts[Math.floor(Math.random() * aircrafts.length)];
      const tempUpdate: TemperatureReading = {
        id: Date.now(),
        aircraftId: randomAircraft.id,
        messageId: `TEST_MSG_${Date.now()}`,
        cabinZone: randomAircraft.cabinZone,
        temperatureCelsius: 20 + Math.random() * 10,
        temperatureFahrenheit: (20 + Math.random() * 10) * 9/5 + 32,
        status: 'NORMAL' as const,
        timestamp: new Date().toISOString(),
        notes: 'Test temperature update',
        createdAt: new Date().toISOString()
      };
      queueMessage('temperature', tempUpdate);
    }
  };

  const testAlarmUpdate = () => {
    if (aircrafts.length > 0) {
      const randomAircraft = aircrafts[Math.floor(Math.random() * aircrafts.length)];
      const alarm: TemperatureAlarm = {
        id: `TEST_ALM_${Date.now()}`,
        aircraftId: randomAircraft.id,
        severity: 'MEDIUM',
        description: 'Test alarm',
        triggeredAt: new Date().toISOString(),
        resolved: false
      };
      queueMessage('alarm', alarm);
    }
  };

  const testStatusUpdate = () => {
    if (aircrafts.length > 0) {
      const randomAircraft = aircrafts[Math.floor(Math.random() * aircrafts.length)];
      const newStatus = ['ACTIVE', 'MAINTENANCE', 'GROUNDED'][Math.floor(Math.random() * 3)] as 'ACTIVE' | 'MAINTENANCE' | 'GROUNDED';
      queueMessage('status', { aircraftId: randomAircraft.id, status: newStatus });
    }
  };

  if (loading) {
    return <div className="loading">Loading aircraft data...</div>;
  }

  if (error) {
    return <div className="error">Error: {error}</div>;
  }

  return (
    <div className="aircraft-dashboard">
      <div className="dashboard-header">
        <h1>✈️ Aircraft Fleet Temperature Dashboard</h1>
        <div className="last-update">
          Last Update: {lastUpdateDisplay.toLocaleTimeString()}
        </div>
      </div>

      {/* Summary Cards */}
      <div className="summary-cards">
        <div className="summary-card">
          <h3>Total Aircraft</h3>
          <div className="summary-value">{summaryData.totalAircraft}</div>
          <div className="summary-trend">
            <span className="trend-label">Active Fleet</span>
          </div>
        </div>
        
        <div className="summary-card alarm-active">
          <h3>Active Alarms</h3>
          <div className="summary-value">{summaryData.activeAlarms}</div>
          <div className="summary-trend">
            <span className="trend-label">Requires Attention</span>
          </div>
        </div>
        
        <div className="summary-card critical-status">
          <h3>Critical Status</h3>
          <div className="summary-value">{summaryData.criticalStatus}</div>
          <div className="summary-trend">
            <span className="trend-label">Maintenance/Grounded</span>
          </div>
        </div>
      </div>

      {/* Test Buttons */}
      <div className="test-controls">
        <button onClick={testTemperatureUpdate} className="test-btn">
          🧪 Test Temperature Update
        </button>
        <button onClick={testAlarmUpdate} className="test-btn">
          🚨 Test Alarm Update
        </button>
        <button onClick={testStatusUpdate} className="test-btn">
          ✈️ Test Status Update
        </button>
      </div>

      {/* Fleet Status Chart */}
      <div className="chart-section">
        <h2>Fleet Status Overview</h2>
        <div className="chart-container">
          {fleetStatusData && (
            <Bar 
              data={fleetStatusData}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                  legend: {
                    display: false
                  }
                },
                animation: false, // Disable animations for better performance
                interaction: {
                  intersect: false
                }
              }}
            />
          )}
        </div>
      </div>

      {/* Aircraft Grid */}
      <div className="aircraft-grid">
        <h2>Aircraft Fleet</h2>
        <div className="aircraft-cards">
          {aircrafts.map(aircraft => (
            <AircraftCard
              key={aircraft.id}
              aircraft={aircraft}
              onClick={() => handleAircraftSelect(aircraft.id)}
            />
          ))}
        </div>
      </div>

      {/* Alarms Section */}
      <div className="alarms-section">
        <h2>Active Alarms</h2>
        <div className="alarm-cards">
          {alarms.filter(alarm => !alarm.resolved).map(alarm => (
            <AlarmCard
              key={alarm.id}
              alarm={alarm}
              aircraft={aircrafts.find(a => a.id === alarm.aircraftId)}
              onResolve={() => resolveAlarm(alarm.id)}
            />
          ))}
        </div>
      </div>

      {/* Temperature History Modal */}
      {showHistoryModal && selectedAircraftId && (
        <div className="modal-overlay" onClick={closeHistoryModal}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h2>Temperature History</h2>
              <button className="modal-close-btn" onClick={closeHistoryModal}>×</button>
            </div>
            <div className="modal-body">
              {aircrafts.find(a => a.id === selectedAircraftId) && (
                <div className="aircraft-info">
                  <div className="info-grid">
                    <div className="info-item">
                      <span className="info-label">Registration:</span>
                      <span className="info-value">{aircrafts.find(a => a.id === selectedAircraftId)?.registration}</span>
                    </div>
                    <div className="info-item">
                      <span className="info-label">Model:</span>
                      <span className="info-value">{aircrafts.find(a => a.id === selectedAircraftId)?.model}</span>
                    </div>
                    <div className="info-item">
                      <span className="info-label">Current Temperature:</span>
                      <span className="info-value">{aircrafts.find(a => a.id === selectedAircraftId)?.currentTemperature}°C</span>
                    </div>
                    <div className="info-item">
                      <span className="info-label">Cabin Zone:</span>
                      <span className="info-value">{aircrafts.find(a => a.id === selectedAircraftId)?.cabinZone}</span>
                    </div>
                    <div className="info-item">
                      <span className="info-label">Status:</span>
                      <span className="info-value">{aircrafts.find(a => a.id === selectedAircraftId)?.status}</span>
                    </div>
                    <div className="info-item">
                      <span className="info-label">Last Update:</span>
                      <span className="info-value">{aircrafts.find(a => a.id === selectedAircraftId)?.lastUpdate ? new Date(aircrafts.find(a => a.id === selectedAircraftId)!.lastUpdate).toLocaleString() : 'Unknown'}</span>
                    </div>
                  </div>
                </div>
              )}
              
              {/* Chart Controls */}
              <div className="chart-controls">
                <div className="control-group">
                  <label>Time Range:</label>
                  <select 
                    value={chartTimeRange} 
                    onChange={(e) => setChartTimeRange(e.target.value as '1h' | '6h' | '24h' | '7d')}
                    className="time-range-select"
                  >
                    <option value="1h">Last 1 Hour</option>
                    <option value="6h">Last 6 Hours</option>
                    <option value="24h">Last 24 Hours</option>
                    <option value="7d">Last 7 Days</option>
                  </select>
                </div>
                
                <div className="control-group">
                  <label>Mode:</label>
                  <div className="toggle-switch">
                    <input
                      type="checkbox"
                      id="realtime-toggle"
                      checked={isRealTimeMode}
                      onChange={(e) => setIsRealTimeMode(e.target.checked)}
                    />
                    <label htmlFor="realtime-toggle" className="toggle-label">
                      <span className="toggle-text">Real-time</span>
                      <span className="toggle-indicator"></span>
                    </label>
                  </div>
                </div>
                
                <div className="control-group">
                  <span className="data-info">
                    📊 {chartData.length} readings • 
                    {isRealTimeMode ? ' 🔴 Live' : ' ⏸️ Paused'}
                  </span>
                </div>
              </div>

              {temperatureHistoryData && (
                <div className="chart-container">
                  <h3>Temperature Trend - {chartTimeRange.toUpperCase()}</h3>
                  <Line 
                    data={temperatureHistoryData}
                    options={{
                      responsive: true,
                      maintainAspectRatio: false,
                      plugins: {
                        legend: {
                          display: false
                        }
                      },
                      animation: false, // Disable animations for better performance
                      interaction: {
                        intersect: false
                      },
                      scales: {
                        x: {
                          title: {
                            display: true,
                            text: 'Time'
                          }
                        },
                        y: {
                          beginAtZero: false,
                          title: {
                            display: true,
                            text: 'Temperature (°C)'
                          }
                        }
                      }
                    }}
                  />
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
});

// Memoized Aircraft Card Component
const AircraftCard: React.FC<{
  aircraft: Aircraft;
  onClick: () => void;
}> = React.memo(({ aircraft, onClick }) => (
  <div className="aircraft-card" onClick={onClick}>
    <div className="aircraft-header">
      <h3>{aircraft.registration}</h3>
      <span className={`status-badge status-${aircraft.status.toLowerCase()}`}>
        {aircraft.status}
      </span>
    </div>
    <div className="aircraft-details">
      <p><strong>Model:</strong> {aircraft.model}</p>
      <p><strong>Current Temperature:</strong> {aircraft.currentTemperature}°C</p>
      <p><strong>Zone:</strong> {aircraft.cabinZone}</p>
      <p><strong>Last Update:</strong> {aircraft.lastUpdate ? new Date(aircraft.lastUpdate).toLocaleString() : 'Unknown'}</p>
    </div>
  </div>
));

// Memoized Alarm Card Component
const AlarmCard: React.FC<{
  alarm: TemperatureAlarm;
  aircraft?: Aircraft;
  onResolve: () => void;
}> = React.memo(({ alarm, aircraft, onResolve }) => (
  <div className={`alarm-card severity-${alarm.severity.toLowerCase()}`}>
    <div className="alarm-header">
      <h4>Alarm #{alarm.id}</h4>
      <span className={`severity-badge severity-${alarm.severity.toLowerCase()}`}>
        {alarm.severity}
      </span>
    </div>
    <div className="alarm-details">
      <p><strong>Aircraft:</strong> {aircraft?.registration || alarm.aircraftId}</p>
      <p><strong>Description:</strong> {alarm.description}</p>
      <p><strong>Triggered:</strong> {new Date(alarm.triggeredAt).toLocaleString()}</p>
    </div>
    <button 
      className="resolve-btn" 
      onClick={onResolve}
      disabled={alarm.resolved}
    >
      {alarm.resolved ? 'Resolved' : 'Resolve'}
    </button>
  </div>
));

export default AircraftDashboard;
