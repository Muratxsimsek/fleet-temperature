import React, { useEffect, useState } from 'react';
import './App.css';
import SockJS from 'sockjs-client';
import { Client } from '@stomp/stompjs';
import AircraftDashboard from './components/AircraftDashboard';
import HeatMapView from './components/HeatMapView';

function App() {
  const [stompClient, setStompClient] = useState<Client | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [currentView, setCurrentView] = useState<'dashboard' | 'heatmap'>('heatmap');
  const [selectedAircraft, setSelectedAircraft] = useState<any>(null);
  const [aircrafts, setAircrafts] = useState<any[]>([]);
  const [websocketAircraftIds, setWebsocketAircraftIds] = useState<Set<string>>(new Set());

  useEffect(() => {
    const socket = new SockJS('http://localhost:8082/ws');
    const client = new Client({
      webSocketFactory: () => socket,
      onConnect: () => {
        console.log('✅ Connected to WebSocket');
        console.log('🔌 WebSocket URL: http://localhost:8082/ws');
        setIsConnected(true);
        setStompClient(client);
      },
      onDisconnect: () => {
        console.log('❌ Disconnected from WebSocket');
        setIsConnected(false);
      },
      onStompError: (error) => {
        console.error('🚨 WebSocket connection error:', error);
        setIsConnected(false);
      },
      debug: (str) => {
        console.log('🔍 STOMP Debug:', str);
      }
    });

    client.activate();

    return () => {
      if (client && client.connected) {
        console.log('🔄 Cleaning up WebSocket connection');
        client.deactivate();
      }
    };
  }, []);

  return (
    <div className="App">
      {/* Navigation Header */}
      <nav className="app-navigation">
        <div className="nav-container">
          <div className="nav-left">
            <h1 className="nav-title">✈️ Fleet Temperature System</h1>
            <span className="nav-subtitle">- Heat Map View</span>
          </div>
          <div className="nav-buttons">
            <button 
              className={`nav-btn primary ${currentView === 'heatmap' ? 'active' : ''}`}
              onClick={() => setCurrentView('heatmap')}
            >
              🔥 Heat Map (Primary)
            </button>
            <div className="aircraft-selector">
              <select 
                value={selectedAircraft?.id || ''} 
                onChange={(e) => setSelectedAircraft(aircrafts.find(a => a.id === e.target.value) || null)}
              >
                <option value="">Choose an aircraft...</option>
                {aircrafts.map(aircraft => (
                  <option key={aircraft.id} value={aircraft.id}>
                    {websocketAircraftIds.has(aircraft.id) ? '📡 ' : '💾 '}
                    {aircraft.registration} - {aircraft.model}
                    {websocketAircraftIds.has(aircraft.id) ? ' (Live)' : ''}
              </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="app-main">
        {currentView === 'dashboard' && (
          <AircraftDashboard stompClient={stompClient} isConnected={isConnected} />
        )}
        {currentView === 'heatmap' && (
          <HeatMapView 
            stompClient={stompClient} 
            isConnected={isConnected}
            selectedAircraft={selectedAircraft}
            setSelectedAircraft={setSelectedAircraft}
            aircrafts={aircrafts}
            setAircrafts={setAircrafts}
            websocketAircraftIds={websocketAircraftIds}
            setWebsocketAircraftIds={setWebsocketAircraftIds}
          />
        )}
      </main>
    </div>
  );
}

export default App;
