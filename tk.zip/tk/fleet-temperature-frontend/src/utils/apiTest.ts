// API Test Utilities for Wrapper Response Format
import { API_CONFIG, parseWrapperResponse, handleApiResponse, getFieldValue } from '../config/api';

// Test wrapper response parsing
export const testWrapperResponse = () => {
  console.log('🧪 Testing Wrapper Response Format...');
  
  // Test success response
  const successResponse = {
    "success": true,
    "message": "Aircraft temperatures retrieved successfully",
    "data": [
      {
        "id": "TC-JJ0",
        "registration": "TC-JJ0",
        "model": "Boeing 737-800",
        "status": "ACTIVE",
        "currentTemperature": 25.0,
        "cabinZone": "MID",
        "lastUpdate": "2025-08-24T05:30:00"
      }
    ],
    "errorCode": null,
    "timestamp": "2025-08-24T05:30:00"
  };
  
  const parsedSuccess = parseWrapperResponse(successResponse);
  console.log('✅ Success Response Parsed:', parsedSuccess);
  
  // Test error response
  const errorResponse = {
    "success": false,
    "message": "Failed to retrieve temperature history",
    "data": [],
    "errorCode": "TEMPERATURE_HISTORY_ERROR",
    "timestamp": "2025-08-24T05:30:00"
  };
  
  const parsedError = parseWrapperResponse(errorResponse);
  console.log('❌ Error Response Parsed:', parsedError);
  
  // Test direct response (backward compatibility)
  const directResponse = [
    {
      "id": "TC-ABC",
      "registration": "TC-ABC",
      "model": "Airbus A320",
      "status": "ACTIVE",
      "currentTemperature": 22.5,
      "cabinZone": "FWD",
      "lastUpdate": "2025-08-24T05:30:00"
    }
  ];
  
  const parsedDirect = parseWrapperResponse(directResponse);
  console.log('🔄 Direct Response Parsed:', parsedDirect);
  
  return {
    success: parsedSuccess,
    error: parsedError,
    direct: parsedDirect
  };
};

// Test API endpoints with wrapper response
export const testApiEndpoints = async () => {
  console.log('🧪 Testing API Endpoints...');
  
  const endpoints = [
    API_CONFIG.ENDPOINTS.AIRCRAFT_TEMPERATURES,
    API_CONFIG.ENDPOINTS.ACTIVE_ALARMS,
    API_CONFIG.ENDPOINTS.TEMPERATURE_ALARMS
  ];
  
  for (const endpoint of endpoints) {
    try {
      console.log(`🔍 Testing endpoint: ${endpoint}`);
      const response = await fetch(`http://localhost:8080${endpoint}`);
      
      if (response.ok) {
        const data = await response.json();
        const parsed = parseWrapperResponse(data);
        console.log(`✅ ${endpoint}:`, parsed);
      } else {
        console.log(`❌ ${endpoint}: HTTP ${response.status}`);
      }
    } catch (error) {
      console.log(`❌ ${endpoint}: Error -`, error);
    }
  }
};

// Test field mapping with different response formats
export const testFieldMapping = () => {
  console.log('🧪 Testing Field Mapping...');
  
  const testAircraft = {
    "aircraftId": "TC-TEST",
    "tailNumber": "TC-TEST",
    "aircraftModel": "Boeing 787",
    "aircraftStatus": "ACTIVE",
    "temperature": 24.5,
    "zone": "MID",
    "flightRoute": "Istanbul - London",
    "origin": "Istanbul",
    "arrival": "London",
    "updatedAt": "2025-08-24T05:30:00"
  };
  
  console.log('🔍 Test Aircraft Object:', testAircraft);
  
  // Test ID mapping
  const id = getFieldValue(testAircraft, API_CONFIG.FIELD_MAPPINGS.AIRCRAFT.ID, 'UNKNOWN');
  console.log('🆔 ID mapped:', id);
  
  // Test registration mapping
  const registration = getFieldValue(testAircraft, API_CONFIG.FIELD_MAPPINGS.AIRCRAFT.REGISTRATION, 'UNKNOWN');
  console.log('📝 Registration mapped:', registration);
  
  // Test model mapping
  const model = getFieldValue(testAircraft, API_CONFIG.FIELD_MAPPINGS.AIRCRAFT.MODEL, 'Unknown Model');
  console.log('✈️ Model mapped:', model);
  
  // Test temperature mapping
  const temperature = getFieldValue(testAircraft, API_CONFIG.FIELD_MAPPINGS.AIRCRAFT.TEMPERATURE, 22.0);
  console.log('🌡️ Temperature mapped:', temperature);
  
  return {
    id,
    registration,
    model,
    temperature
  };
};

// Export test functions
export default {
  testWrapperResponse,
  testApiEndpoints,
  testFieldMapping
};
